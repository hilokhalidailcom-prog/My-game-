// ===== اللاعب =====
class Player {
  constructor() {
    this.x = 0;
    this.y = 0;
    this.r = CONFIG.PLAYER_RADIUS;
    this.speed = CONFIG.PLAYER_SPEED;
    this.aimAngle = 0;
    this.hitCooldown = 0;
    this.armor = null;
    this.health = CONFIG.PLAYER_BASE_HP;
    this.maxHealth = CONFIG.PLAYER_BASE_HP;
  }

  reset() {
    this.x = 0;
    this.y = 0;
    this.aimAngle = 0;
    this.hitCooldown = 0;
    this.armor = null;
    this.health = CONFIG.PLAYER_BASE_HP;
    this.maxHealth = CONFIG.PLAYER_BASE_HP;
  }

  draw(ctx, camera, game) {
    const sx = this.x - camera.x;
    const sy = this.y - camera.y;

    // هالة الدرع
    if (this.armor) {
      ctx.strokeStyle = this.armor.color;
      ctx.lineWidth = 3;
      ctx.globalAlpha = 0.7;
      ctx.beginPath();
      ctx.arc(sx, sy, this.r + 6 + Math.sin(Date.now() / 200) * 2, 0, Math.PI * 2);
      ctx.stroke();
      ctx.globalAlpha = 1;
    }

    ctx.fillStyle = 'rgba(0,0,0,0.4)';
    ctx.beginPath();
    ctx.ellipse(sx, sy + this.r * 0.8, this.r * 0.85, this.r * 0.3, 0, 0, Math.PI * 2);
    ctx.fill();

    const flashing = this.hitCooldown > 0 && Math.floor(this.hitCooldown / 4) % 2 === 0;
    const bodyColor = flashing ? '#ff6666' : '#4fc3f7';
    const g = ctx.createRadialGradient(sx - 4, sy - 4, 2, sx, sy, this.r);
    g.addColorStop(0, flashing ? '#ff9999' : '#90caf9');
    g.addColorStop(1, bodyColor);
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(sx, sy, this.r, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#1565c0';
    ctx.lineWidth = 2;
    ctx.stroke();

    // السلاح
    ctx.save();
    ctx.translate(sx, sy);
    ctx.rotate(this.aimAngle);
    game.drawWeaponShape(ctx, game.currentWeapon, game.weaponLevels[game.currentWeapon] || 1);
    ctx.restore();

    // عيون
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.arc(sx - 4, sy - 4, 3.5, 0, Math.PI * 2);
    ctx.arc(sx + 4, sy - 4, 3.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#000';
    ctx.beginPath();
    ctx.arc(sx - 4, sy - 4, 1.8, 0, Math.PI * 2);
    ctx.arc(sx + 4, sy - 4, 1.8, 0, Math.PI * 2);
    ctx.fill();

    // خط التصويب
    ctx.strokeStyle = 'rgba(255,255,0,0.3)';
    ctx.lineWidth = 1;
    ctx.setLineDash([5, 5]);
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.lineTo(sx + Math.cos(this.aimAngle) * 120, sy + Math.sin(this.aimAngle) * 120);
    ctx.stroke();
    ctx.setLineDash([]);
  }
}