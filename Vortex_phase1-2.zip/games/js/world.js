// ===== نظام العالم اللانهائي (Chunks) =====
class World {
  constructor() {
    this.chunks = new Map(); // key: "x,y" -> chunkData
    this.trees = [];
  }

  key(cx, cy) { return cx + ',' + cy; }

  // حصول على chunk أو إنشاؤه
  getChunk(cx, cy, level) {
    const k = this.key(cx, cy);
    if (this.chunks.has(k)) return this.chunks.get(k);

    const chunk = this.generateChunk(cx, cy, level);
    this.chunks.set(k, chunk);

    // حد أقصى للحجم لمنع استهلاك الذاكرة
    if (this.chunks.size > 200) {
      const firstKey = this.chunks.keys().next().value;
      this.chunks.delete(firstKey);
    }

    return chunk;
  }

  generateChunk(cx, cy, level) {
    const size = CONFIG.CHUNK_SIZE;
    const baseX = cx * size;
    const baseY = cy * size;

    const trees = [];
    const treeCount = Math.floor(rand(4, 10));

    for (let i = 0; i < treeCount; i++) {
      trees.push({
        x: baseX + rand(40, size - 40),
        y: baseY + rand(40, size - 40),
        r: rand(20, 40),
        shade: rand(0.4, 0.8)
      });
    }

    // هل يوجد معسكر في هذا الـ chunk؟
    let camp = null;
    if (Math.random() < CONFIG.CAMP_CHANCE_PER_CHUNK && Math.abs(cx) + Math.abs(cy) > 1) {
      camp = generateCamp(baseX, baseY, size, level);
    }

    return { cx, cy, baseX, baseY, trees, camp };
  }

  // الحصول على كل الـ chunks المرئية
  getVisibleChunks(cameraX, cameraY, viewW, viewH, level) {
    const size = CONFIG.CHUNK_SIZE;
    const cx0 = Math.floor(cameraX / size) - 1;
    const cy0 = Math.floor(cameraY / size) - 1;
    const cx1 = Math.floor((cameraX + viewW) / size) + 1;
    const cy1 = Math.floor((cameraY + viewH) / size) + 1;

    const visible = [];
    for (let cx = cx0; cx <= cx1; cx++) {
      for (let cy = cy0; cy <= cy1; cy++) {
        visible.push(this.getChunk(cx, cy, level));
      }
    }
    return visible;
  }

  reset() {
    this.chunks.clear();
  }
}