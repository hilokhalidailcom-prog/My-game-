// ===== الكلاس الرئيسي للعبة =====
class Game {
  constructor() {
    this.canvas = document.getElementById('game');
    this.ctx = this.canvas.getContext('2d');

    // الأبعاد الحقيقية للحاوية (تتحدث في resizeCanvas)
    this.W = 1;
    this.H = 1;
    this._resizeScheduled = false;

    this.world = new World();
    this.player = new Player();
    this.camera = { x: 0, y: 0 };

    this.coins = 0;
    this.points = 0;
    this.level = 1;
    this.coinsForNextLevel = CONFIG.COINS_PER_LEVEL_BASE;
    this.lastBossLevel = 0;

    this.unlockedWeapons = ['pistol'];
    this.weaponLevels = { pistol: 1 };
    this.currentWeapon = 'pistol';
    this.shootTimer = 0;

    this.coinsArr = [];
    this.bullets = [];
    this.enemies = [];
    this.particles = [];
    this.items = [];
    this.armorDrops = [];
    this.followers = [];
    this.boss = null;
    this.bossProjectiles = [];
    this.enemyProjectiles = [];

    // أدوات اللاعب (المخزون)
    this.inventory = {};

    // تأثيرات
    this.freezeTimer = 0;
    this.rageTimer = 0;

    this.gameRunning = false;

    this.joystick = { dx: 0, dy: 0 };
    this.firing = false;
    this.keys = {};

    // أول قياس بعد ما الـ DOM يستقر
    this.resizeCanvas();

    window.addEventListener('resize', () => this._scheduleResize());
    window.addEventListener('orientationchange', () => this._scheduleResize());

    // دعم visualViewport لكيبورد الموبايل
    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', () => this._scheduleResize());
      window.visualViewport.addEventListener('scroll', () => this._scheduleResize());
    }

    this.setupInput();
  }

  _scheduleResize() {
    if (this._resizeScheduled) return;
    this._resizeScheduled = true;
    requestAnimationFrame(() => {
      this._resizeScheduled = false;
      this.resizeCanvas();
    });
  }

  resizeCanvas() {
    const parent = this.canvas.parentElement; // #gameContainer
    if (!parent) return;

    const rect = parent.getBoundingClientRect();
    const newW = Math.max(1, Math.floor(rect.width));
    const newH = Math.max(1, Math.floor(rect.height));

    // لو ما تغير شيء، لا نعمل شيء
    if (newW === this.W && newH === this.H &&
        this.canvas.width === newW && this.canvas.height === newH) {
      return;
    }

    this.W = newW;
    this.H = newH;
    this.canvas.width = newW;
    this.canvas.height = newH;

    // CSS يملأ الحاوية بالضبط
    this.canvas.style.width = '100%';
    this.canvas.style.height = '100%';

    console.log('📐 resizeCanvas →', this.W, 'x', this.H);
  }

  setupInput() {
    window.addEventListener('keydown', e => { this.keys[e.key.toLowerCase()] = true; });
    window.addEventListener('keyup', e => { this.keys[e.key.toLowerCase()] = false; });
  }

  reset() {
    this.world.reset();
    this.player.reset();
    this.camera.x = 0;
    this.camera.y = 0;
    this.coins = 0;
    this.points = 0;
    this.level = 1;
    this.coinsForNextLevel = CONFIG.COINS_PER_LEVEL_BASE;
    this.lastBossLevel = 0;
    this.unlockedWeapons = ['pistol'];
    this.weaponLevels = { pistol: 1 };
    this.currentWeapon = 'pistol';
    this.shootTimer = 0;
    this.coinsArr = [];
    this.bullets = [];
    this.enemies = [];
    this.particles = [];
    this.items = [];
    this.armorDrops = [];
    this.followers = [];
    this.boss = null;
    this.bossProjectiles = [];
    this.enemyProjectiles = [];
    this.inventory = {};
    this.freezeTimer = 0;
    this.rageTimer = 0;

    for (let i = 0; i < 15; i++) this.spawnCoinNearPlayer();
  }

  spawnCoinNearPlayer() {
    const angle = Math.random() * Math.PI * 2;
    const dist = 200 + Math.random() * 800;
    this.coinsArr.push({
      x: this.player.x + Math.cos(angle) * dist,
      y: this.player.y + Math.sin(angle) * dist,
      r: 12,
      pulse: Math.random() * Math.PI * 2
    });
  }

  spawnParticles(x, y, color, count, speed = 3) {
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = Math.random() * speed + 0.5;
      this.particles.push({
        x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
        life: 30, maxLife: 30, color, size: Math.random() * 3 + 2
      });
    }
  }
}
