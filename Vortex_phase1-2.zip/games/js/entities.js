// ===== الكيانات =====
function createEnemy(x, y, level, forceType = null) {
  const availableTypes = CONFIG.ENEMY_TYPES.filter(t => t.minLevel <= level);
  const type = forceType
    ? CONFIG.ENEMY_TYPES.find(t => t.id === forceType)
    : availableTypes[Math.floor(Math.random() * availableTypes.length)];

  const baseHp = 20 + level * 8;
  const baseSpeed = 0.9 + level * 0.08;
  const baseDamage = 6 + level * 1.5;

  return {
    x, y, r: type.r,
    hp: baseHp * type.hpMul,
    maxHp: baseHp * type.hpMul,
    speed: baseSpeed * type.spMul,
    damage: baseDamage * type.dmgMul,
    color: type.color,
    typeId: type.id,
    typeName: type.name,
    weaponIcon: type.weaponIcon || null,
    wobble: Math.random() * Math.PI * 2,
    hitFlash: 0,
    state: 'chase', // 'chase' | 'wander' | 'return'
    homeX: x,
    homeY: y,
    wanderAngle: Math.random() * Math.PI * 2,
    wanderTimer: 0,
    // ---- الأعداء بعيدو المدى ----
    ranged: !!type.ranged,
    rangedDistance: type.rangedRange || 300,
    projColor: type.projColor || type.color,
    shootTimer: type.ranged ? (40 + Math.random() * 40) : undefined
  };
}

function createBoss(x, y, bossLevel) {
  const hp = 500 + bossLevel * 400;
  return {
    x, y, r: 50,
    hp, maxHp: hp,
    speed: 1.1 + bossLevel * 0.15,
    damage: 20 + bossLevel * 6,
    color: '#b71c1c',
    wobble: Math.random() * Math.PI * 2,
    hitFlash: 0,
    shootTimer: 60,
    bossLevel
  };
}

// ===== أنواع قادة المعسكرات (كل نوع له طريقة هجوم مختلفة) =====
const CAMP_LEADER_TYPES = [
  { id: 'goblin_boss',    name: 'زعيم الغوبلن',      color: '#8b0000', icon: '🦴', projColor: '#e0e0e0', projSpeed: 5, attack: 'ranged' },
  { id: 'dragon_lord',    name: 'سيد التنانين',      color: '#ff6f00', icon: '🔥', projColor: '#ff5722', projSpeed: 4, attack: 'ranged_aoe' },
  { id: 'hippo_king',     name: 'ملك فرس النهر',     color: '#4e342e', icon: '🗡️', projColor: '#795548', projSpeed: 6, attack: 'melee_spike' },
  { id: 'orc_warlord',    name: 'قائد الأورك',        color: '#4a7c2f', icon: '⚔️', projColor: '#8bc34a', projSpeed: 5, attack: 'ranged' },
  { id: 'demon_overlord', name: 'سيد الشياطين',      color: '#6a0dad', icon: '💜', projColor: '#e040fb', projSpeed: 6, attack: 'ranged_aoe' },
  { id: 'skeleton_king',  name: 'ملك الهياكل',       color: '#cfd8dc', icon: '☠️', projColor: '#ffffff', projSpeed: 7, attack: 'ranged' },
  { id: 'troll_chief',    name: 'زعيم الترول',       color: '#5d4037', icon: '🪨', projColor: '#795548', projSpeed: 3, attack: 'melee_spike' },
  { id: 'vampire_lord',   name: 'أمير مصاصي الدماء', color: '#b71c1c', icon: '🩸', projColor: '#b71c1c', projSpeed: 6, attack: 'ranged' }
];
// ملاحظة: يمكن إضافة أي عدد من الأنواع هنا مستقبلاً بنفس الشكل بدون تعديل أي كود آخر.

function createCampLeader(x, y, level, archetype) {
  const arch = archetype || CAMP_LEADER_TYPES[Math.floor(Math.random() * CAMP_LEADER_TYPES.length)];
  const baseHp = 150 + level * 30;
  return {
    x, y, r: 32,
    hp: baseHp,
    maxHp: baseHp,
    speed: 1.3 + level * 0.08,
    damage: 15 + level * 3,
    color: arch.color,
    wobble: 0,
    hitFlash: 0,
    shootTimer: 90 + Math.random() * 40,
    isLeader: true,
    leaderArchetype: arch,
    state: 'chase',
    homeX: x,
    homeY: y,
    wanderAngle: Math.random() * Math.PI * 2,
    wanderTimer: 0
  };
}
