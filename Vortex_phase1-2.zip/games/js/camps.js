// ===== نظام المعسكرات =====
function generateCamp(baseX, baseY, size, level) {
  const centerX = baseX + size / 2;
  const centerY = baseY + size / 2;

  // تحديد حجم المعسكر
  let enemyCount;
  const roll = Math.random();

  if (roll < CONFIG.CAMP_HUGE_CHANCE) {
    // معسكر ضخم
    enemyCount = Math.floor(rand(CONFIG.CAMP_HUGE_MIN, CONFIG.CAMP_HUGE_MAX));
  } else {
    enemyCount = Math.floor(rand(CONFIG.CAMP_MIN_ENEMIES, CONFIG.CAMP_MAX_ENEMIES));
  }

  // نوع القائد (كل نوع له طريقة هجوم مختلفة: رمي عظام، نار، أشواك...)
  const leaderArchetype = CAMP_LEADER_TYPES[Math.floor(Math.random() * CAMP_LEADER_TYPES.length)];

  return {
    id: Math.random().toString(36).substr(2, 9),
    x: centerX,
    y: centerY,
    radius: 350,
    enemyCount,
    leaderArchetype,
    level,
    spawned: false,
    cleared: false,
    enemies: [],
    leader: null,
    loot: []
  };
}

// عند دخول اللاعب للمعسكر -> spawn الأعداء
function activateCamp(camp, level) {
  if (camp.spawned) return;
  camp.spawned = true;

  // قائد
  camp.leader = createCampLeader(
    camp.x + rand(-80, 80),
    camp.y + rand(-80, 80),
    level,
    camp.leaderArchetype
  );

  // أعداء عشوائيين
  const maxToSpawn = Math.min(camp.enemyCount, 150); // حد لأداء اللعبة
  for (let i = 0; i < maxToSpawn; i++) {
    const angle = Math.random() * Math.PI * 2;
    const dist = rand(50, camp.radius);
    const ex = camp.x + Math.cos(angle) * dist;
    const ey = camp.y + Math.sin(angle) * dist;

    const availableTypes = CONFIG.ENEMY_TYPES.filter(t => t.minLevel <= level);
    const type = availableTypes[Math.floor(Math.random() * availableTypes.length)];
    const enemy = createEnemy(ex, ey, level + 2, type.id);
    camp.enemies.push(enemy);
  }

  return camp;
}

function drawCamp(ctx, camp, camera) {
  const sx = camp.x - camera.x;
  const sy = camp.y - camera.y;

  if (sx < -600 || sx > ctx.canvas.width + 600) return;

  // دائرة المعسكر
  ctx.strokeStyle = camp.cleared ? 'rgba(76,175,80,0.3)' : 'rgba(255,87,34,0.5)';
  ctx.lineWidth = 3;
  ctx.setLineDash([10, 10]);
  ctx.beginPath();
  ctx.arc(sx, sy, camp.radius, 0, Math.PI * 2);
  ctx.stroke();
  ctx.setLineDash([]);

  // علم المعسكر
  ctx.fillStyle = camp.cleared ? '#4caf50' : '#ff5722';
  ctx.beginPath();
  ctx.moveTo(sx, sy - 60);
  ctx.lineTo(sx + 30, sy - 45);
  ctx.lineTo(sx, sy - 30);
  ctx.fill();

  ctx.strokeStyle = '#333';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(sx, sy - 60);
  ctx.lineTo(sx, sy + 10);
  ctx.stroke();

  // اسم المعسكر
  ctx.fillStyle = camp.cleared ? '#7cfc00' : '#ff5722';
  ctx.font = 'bold 14px Arial';
  ctx.textAlign = 'center';
  ctx.fillText(
    (camp.cleared ? '✅ ' : '🏕️ ') + 'معسكر ' + camp.enemyCount +
    (camp.leaderArchetype ? ' — ' + camp.leaderArchetype.icon + ' ' + camp.leaderArchetype.name : ''),
    sx, sy + 30
  );

  // عداد الأعداء الحيين
  if (camp.spawned && !camp.cleared) {
    const alive = camp.enemies.length + (camp.leader ? 1 : 0);
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 12px Arial';
    ctx.fillText('متبقي: ' + alive, sx, sy + 48);
  }
}