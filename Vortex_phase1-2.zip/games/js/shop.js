// ===== نظام المتجر =====
const SHOP_ITEMS = {
  followers: [
    { typeId: 'guard',       price: FOLLOWER_TYPES.guard.price, icon: '🛡️', name: 'حارس',       desc: FOLLOWER_TYPES.guard.desc },
    { typeId: 'archer',      price: FOLLOWER_TYPES.archer.price, icon: '🏹', name: 'رامي',       desc: FOLLOWER_TYPES.archer.desc },
    { typeId: 'mage',        price: FOLLOWER_TYPES.mage.price, icon: '🔮', name: 'ساحر',       desc: FOLLOWER_TYPES.mage.desc },
    { typeId: 'healer',      price: FOLLOWER_TYPES.healer.price, icon: '💚', name: 'معالج',     desc: FOLLOWER_TYPES.healer.desc },
    { typeId: 'knight',      price: FOLLOWER_TYPES.knight.price, icon: '⚔️', name: 'فارس',      desc: FOLLOWER_TYPES.knight.desc },
    { typeId: 'dragon_pet',  price: FOLLOWER_TYPES.dragon_pet.price, icon: '🐉', name: 'تنين صغير', desc: FOLLOWER_TYPES.dragon_pet.desc },
    { typeId: 'hunter',      price: FOLLOWER_TYPES.hunter.price, icon: '🎯', name: 'الصياد',        desc: FOLLOWER_TYPES.hunter.desc },
    { typeId: 'duck',        price: FOLLOWER_TYPES.duck.price, icon: '🦆', name: 'البطة المهاجمة',  desc: FOLLOWER_TYPES.duck.desc },
    { typeId: 'flamer',      price: FOLLOWER_TYPES.flamer.price, icon: '🔥', name: 'رامي اللهب',     desc: FOLLOWER_TYPES.flamer.desc },
    { typeId: 'boxer',       price: FOLLOWER_TYPES.boxer.price, icon: '🥊', name: 'الملاكم',         desc: FOLLOWER_TYPES.boxer.desc },
    { typeId: 'rescuer',     price: FOLLOWER_TYPES.rescuer.price, icon: '🆘', name: 'المنقذ',         desc: FOLLOWER_TYPES.rescuer.desc },
    { typeId: 'sniper',      price: FOLLOWER_TYPES.sniper.price, icon: '🔭', name: 'القناص',         desc: FOLLOWER_TYPES.sniper.desc },
    { typeId: 'elephant',    price: FOLLOWER_TYPES.elephant.price, icon: '🐘', name: 'الفيل',         desc: FOLLOWER_TYPES.elephant.desc },
    { typeId: 'dragon_ring', price: FOLLOWER_TYPES.dragon_ring.price, icon: '🐲', name: 'التنين',     desc: FOLLOWER_TYPES.dragon_ring.desc }
  ],
  items: [
    { id: 'health_small', price: ITEM_TYPES.health_small.price },
    { id: 'health_big',   price: ITEM_TYPES.health_big.price },
    { id: 'bomb',         price: ITEM_TYPES.bomb.price },
    { id: 'freeze',       price: ITEM_TYPES.freeze.price },
    { id: 'rage',         price: ITEM_TYPES.rage.price },
    { id: 'magnet',       price: ITEM_TYPES.magnet.price },
    { id: 'shield_kit',   price: ITEM_TYPES.shield_kit.price }
  ]
};