// ===== إدارة الواجهة =====
const UI = {
  coinCountEl: null,
  pointsCountEl: null,
  healthFill: null,
  healthText: null,
  armorBar: null,
  armorFill: null,
  armorText: null,
  weaponNameEl: null,
  weaponLvlEl: null,
  levelMsgEl: null,
  bossWarningEl: null,
  notificationEl: null,
  levelNumEl: null,
  miniMapCanvas: null,
  miniCtx: null,

  init() {
    this.coinCountEl = document.getElementById('coinCount');
    this.pointsCountEl = document.getElementById('pointsCount');
    this.healthFill = document.getElementById('healthFill');
    this.healthText = document.getElementById('healthText');
    this.armorBar = document.getElementById('armorBar');
    this.armorFill = document.getElementById('armorFill');
    this.armorText = document.getElementById('armorText');
    this.weaponNameEl = document.getElementById('weaponName');
    this.weaponLvlEl = document.getElementById('weaponLvl');
    this.levelMsgEl = document.getElementById('levelMsg');
    this.bossWarningEl = document.getElementById('bossWarning');
    this.notificationEl = document.getElementById('notification');
    this.levelNumEl = document.getElementById('levelNum');
    this.miniMapCanvas = document.getElementById('miniMap');
    this.miniCtx = this.miniMapCanvas.getContext('2d');
  },

  updateHUD(game) {
    this.coinCountEl.textContent = game.coins;
    this.pointsCountEl.textContent = game.points;

    const hpPct = Math.max(0, game.player.health / game.player.maxHealth) * 100;
    this.healthFill.style.width = hpPct + '%';
    this.healthText.textContent =
      Math.floor(Math.max(0, game.player.health)) + ' / ' + game.player.maxHealth;

    if (game.player.armor) {
      this.armorBar.style.display = 'block';
      const aPct = Math.max(0, game.player.armor.hp / game.player.armor.maxHp) * 100;
      this.armorFill.style.width = aPct + '%';
      this.armorText.textContent =
        '🛡️ ' + Math.ceil(game.player.armor.hp) + ' / ' + game.player.armor.maxHp;
    } else {
      this.armorBar.style.display = 'none';
    }

    this.weaponNameEl.textContent = WEAPONS[game.currentWeapon].name;
    this.weaponLvlEl.textContent = 'Lv.' + (game.weaponLevels[game.currentWeapon] || 1);
    this.levelNumEl.textContent = game.level;
  },

  showLevelMsg(text) {
    this.levelMsgEl.textContent = text;
    this.levelMsgEl.classList.add('show');
    setTimeout(() => this.levelMsgEl.classList.remove('show'), 1500);
  },

  showBossWarning(text) {
    this.bossWarningEl.textContent = text;
    this.bossWarningEl.classList.add('show');
    setTimeout(() => this.bossWarningEl.classList.remove('show'), 2000);
  },

  showNotification(text) {
    this.notificationEl.textContent = text;
    this.notificationEl.classList.add('show');
    setTimeout(() => this.notificationEl.classList.remove('show'), 1200);
  },

  drawMiniMap(game, camera, W, H) {
    const ctx = this.miniCtx;
    ctx.clearRect(0, 0, 110, 110);
    ctx.fillStyle = 'rgba(20,50,20,0.9)';
    ctx.fillRect(0, 0, 110, 110);

    const range = 4000;
    const sc = 110 / range;

    const cx = game.player.x;
    const cy = game.player.y;

    const toMap = (x, y) => ({
      mx: 55 + (x - cx) * sc,
      my: 55 + (y - cy) * sc
    });

    // معسكرات
    for (const chunk of game.world.chunks.values()) {
      if (!chunk.camp) continue;
      const p = toMap(chunk.camp.x, chunk.camp.y);
      if (p.mx < 0 || p.mx > 110 || p.my < 0 || p.my > 110) continue;
      ctx.fillStyle = chunk.camp.cleared ? '#4caf50' : '#ff5722';
      ctx.beginPath();
      ctx.arc(p.mx, p.my, 3, 0, Math.PI * 2);
      ctx.fill();
    }

    // أعداء
    ctx.fillStyle = '#ff1744';
    for (const e of game.enemies) {
      const p = toMap(e.x, e.y);
      if (p.mx < 0 || p.mx > 110 || p.my < 0 || p.my > 110) continue;
      ctx.fillRect(p.mx - 1, p.my - 1, 2, 2);
    }

    // عملات
    ctx.fillStyle = '#ffd700';
    for (const c of game.coinsArr) {
      const p = toMap(c.x, c.y);
      if (p.mx < 0 || p.mx > 110 || p.my < 0 || p.my > 110) continue;
      ctx.fillRect(p.mx - 1, p.my - 1, 2, 2);
    }

    // أتباع
    ctx.fillStyle = '#2196f3';
    for (const f of game.followers) {
      const p = toMap(f.x, f.y);
      if (p.mx < 0 || p.mx > 110 || p.my < 0 || p.my > 110) continue;
      ctx.fillRect(p.mx - 1, p.my - 1, 2, 2);
    }

    // زعيم
    if (game.boss) {
      const p = toMap(game.boss.x, game.boss.y);
      if (p.mx >= 0 && p.mx <= 110 && p.my >= 0 && p.my <= 110) {
        ctx.fillStyle = '#ff0000';
        ctx.beginPath();
        ctx.arc(p.mx, p.my, 4, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // اللاعب في الوسط
    ctx.fillStyle = '#00e5ff';
    ctx.beginPath();
    ctx.arc(55, 55, 3, 0, Math.PI * 2);
    ctx.fill();
  }
};