// ===== دالة مساعدة: رقم عشوائي بين min و max =====
function rand(min, max) {
  return Math.random() * (max - min) + min;
}

// ===== إعدادات اللعبة =====
const CONFIG = {
  // الخريطة اللانهائية (chunks)
  CHUNK_SIZE: 1200,
  VIEW_CHUNKS: 2, // عدد الـ chunks حول اللاعب

  // اللاعب
  PLAYER_SPEED: 3.6,
  PLAYER_RADIUS: 16,
  PLAYER_BASE_HP: 100,

  // الأعداء
  ENEMY_LOSE_RANGE: 200, // 2 متر = 200 بكسل
  ENEMY_WANDER_SPEED: 0.5,

  // المعسكرات
  CAMP_CHANCE_PER_CHUNK: 0.35, // 35% فرصة أن chunk يحتوي معسكر
  CAMP_MIN_ENEMIES: 10,
  CAMP_MAX_ENEMIES: 200,
  CAMP_HUGE_CHANCE: 0.05, // 5% معسكر ضخم (500-1000)
  CAMP_HUGE_MIN: 500,
  CAMP_HUGE_MAX: 1000,

  // المستويات
  COINS_PER_LEVEL_BASE: 10,
  POINTS_PER_KILL: 5,

  // الأدوات
  ITEM_DROP_CHANCE: 0.08,

  // الوحوش (12 نوع: 10 قريبة المدى + 2 بعيدة المدى)
  ENEMY_TYPES: [
    { id: 'slime',    name: 'سلايم',      color: '#4caf50', hpMul: 0.6, spMul: 0.7,  dmgMul: 0.6, r: 14, minLevel: 1 },
    { id: 'goblin',   name: 'غوبلن',      color: '#8b0000', hpMul: 1.0, spMul: 1.0,  dmgMul: 1.0, r: 18, minLevel: 1 },
    { id: 'orc',      name: 'أورك',       color: '#4a7c2f', hpMul: 1.6, spMul: 0.85, dmgMul: 1.4, r: 22, minLevel: 2, weaponIcon: '⚔️' },
    { id: 'skeleton', name: 'هيكل',       color: '#cfd8dc', hpMul: 1.3, spMul: 1.1,  dmgMul: 1.2, r: 20, minLevel: 2, weaponIcon: '🗡️' },
    { id: 'archer_enemy', name: 'رامي معادٍ', color: '#33691e', hpMul: 1.1, spMul: 0.95, dmgMul: 0.8, r: 19, minLevel: 2,
      ranged: true, rangedRange: 300, projColor: '#8bc34a', weaponIcon: '🏹' },
    { id: 'demon',    name: 'شيطان',      color: '#6a0dad', hpMul: 2.2, spMul: 1.2,  dmgMul: 1.8, r: 24, minLevel: 3, weaponIcon: '🔥' },
    { id: 'ghost',    name: 'شبح',        color: '#b39ddb', hpMul: 1.5, spMul: 1.4,  dmgMul: 1.3, r: 20, minLevel: 3 },
    { id: 'fire_thrower', name: 'راشق نار', color: '#ff3d00', hpMul: 1.7, spMul: 0.8, dmgMul: 1.3, r: 21, minLevel: 4,
      ranged: true, rangedRange: 280, projColor: '#ff6d00', weaponIcon: '🔥' },
    { id: 'troll',    name: 'ترول',       color: '#5d4037', hpMul: 3.0, spMul: 0.7,  dmgMul: 2.2, r: 28, minLevel: 4, weaponIcon: '🪓' },
    { id: 'vampire',  name: 'مصاص دم',    color: '#b71c1c', hpMul: 2.5, spMul: 1.3,  dmgMul: 2.0, r: 22, minLevel: 5, weaponIcon: '🩸' },
    { id: 'werewolf', name: 'ذئب',        color: '#795548', hpMul: 2.8, spMul: 1.5,  dmgMul: 2.3, r: 24, minLevel: 6, weaponIcon: '🦴' },
    { id: 'dragon',   name: 'تنين صغير',  color: '#ff6f00', hpMul: 4.5, spMul: 1.1,  dmgMul: 3.0, r: 30, minLevel: 8, weaponIcon: '🔥' }
  ]
};