// ===== تحديث حالة اللعبة كل إطار (فيزياء، تصادمات، توليد الأعداء) =====
Object.assign(Game.prototype, {
  update() {
    if (!this.gameRunning) return;

    // ---- حركة اللاعب ----
    let dx = this.joystick.dx;
    let dy = this.joystick.dy;
    if (this.keys['w'] || this.keys['arrowup']) dy -= 1;
    if (this.keys['s'] || this.keys['arrowdown']) dy += 1;
    if (this.keys['a'] || this.keys['arrowleft']) dx -= 1;
    if (this.keys['d'] || this.keys['arrowright']) dx += 1;

    const mag = Math.hypot(dx, dy);
    if (mag > 1) { dx /= mag; dy /= mag; }
    if (mag > 0.05) {
      this.player.x += dx * this.player.speed;
      this.player.y += dy * this.player.speed;
    }

    // كاميرا — تعتمد على أبعاد canvas الحقيقية
    this.camera.x = this.player.x - this.W / 2;
    this.camera.y = this.player.y - this.H / 2;

    // ---- إطلاق النار ----
    if (this.shootTimer > 0) this.shootTimer--;
    if (this.firing || this.keys[' ']) this.shoot();

    // ---- اتجاه النظر: يتبع اتجاه التحريك فقط (لا قفل تلقائي على أقرب عدو) ----
    if (mag > 0.05) {
      this.player.aimAngle = Math.atan2(dy, dx);
    }

    // ---- مؤقتات ----
    if (this.freezeTimer > 0) this.freezeTimer--;
    if (this.rageTimer > 0) this.rageTimer--;

    // ---- Chunks (توليد العالم المرئي) ----
    this.world.getVisibleChunks(
      this.camera.x, this.camera.y, this.W, this.H, this.level
    );

    // ---- تنشيط المعسكرات القريبة ----
    for (const chunk of this.world.chunks.values()) {
      if (chunk.camp && !chunk.camp.cleared && !chunk.camp.spawned) {
        const d = Math.hypot(chunk.camp.x - this.player.x, chunk.camp.y - this.player.y);
        if (d < 500) {
          activateCamp(chunk.camp, this.level);
          this.enemies.push(...chunk.camp.enemies);
          this.enemies.push(chunk.camp.leader);
          UI.showNotification('⚔️ معسكر! ' + chunk.camp.enemyCount + ' عدو — بقيادة ' + chunk.camp.leaderArchetype.name);
        }
      }
    }

    // ---- عملات ----
    for (let i = this.coinsArr.length - 1; i >= 0; i--) {
      const c = this.coinsArr[i];
      c.pulse += 0.1;
      if (Math.hypot(this.player.x - c.x, this.player.y - c.y) < this.player.r + c.r) {
        this.coins++;
        UI.updateHUD(this);
        this.spawnParticles(c.x, c.y, '#ffd700', 10, 4);
        this.coinsArr.splice(i, 1);
        if (this.coins >= this.coinsForNextLevel) this.levelUp();
      }
    }

    // ---- علب صحة ----
    for (let i = this.items.length - 1; i >= 0; i--) {
      const it = this.items[i];
      it.pulse += 0.1;
      if (Math.hypot(this.player.x - it.x, this.player.y - it.y) < this.player.r + it.r) {
        this.player.health = Math.min(this.player.health + it.heal, this.player.maxHealth);
        this.spawnParticles(it.x, it.y, '#ff69b4', 15, 4);
        UI.showNotification('❤️ +' + it.heal + ' صحة');
        this.items.splice(i, 1);
        UI.updateHUD(this);
      }
    }

    // ---- دروع ----
    for (let i = this.armorDrops.length - 1; i >= 0; i--) {
      const a = this.armorDrops[i];
      a.pulse += 0.1;
      if (Math.hypot(this.player.x - a.x, this.player.y - a.y) < this.player.r + a.r) {
        this.player.armor = a.armor;
        this.spawnParticles(a.x, a.y, a.armor.color, 15, 4);
        UI.showNotification('🛡️ ' + a.armor.name);
        this.armorDrops.splice(i, 1);
        UI.updateHUD(this);
      }
    }

    // ---- رصاص اللاعب/الأتباع ----
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const b = this.bullets[i];
      b.x += b.vx;
      b.y += b.vy;
      b.life--;
      if (b.life <= 0) { this.bullets.splice(i, 1); continue; }

      let hit = false;
      for (let j = this.enemies.length - 1; j >= 0; j--) {
        const e = this.enemies[j];
        if (Math.hypot(b.x - e.x, b.y - e.y) < e.r + b.r) {
          e.hp -= b.damage;
          e.hitFlash = 6;
          this.spawnParticles(b.x, b.y, b.color, 5, 3);
          hit = true;

          // انفجار (بيض البطة المهاجمة): يضرب كل الأعداء القريبين أيضاً
          if (b.explosive) {
            this.spawnParticles(b.x, b.y, '#ff9800', 14, 5);
            for (const other of this.enemies) {
              if (other === e) continue;
              if (Math.hypot(b.x - other.x, b.y - other.y) < b.explosionRadius) {
                other.hp -= b.damage * 0.6;
                other.hitFlash = 6;
                if (other.hp <= 0) this.killEnemy(other);
              }
            }
          }

          if (e.hp <= 0) this.killEnemy(e);
          break;
        }
      }
      if (!hit && this.boss && Math.hypot(b.x - this.boss.x, b.y - this.boss.y) < this.boss.r + b.r) {
        this.boss.hp -= b.damage;
        this.boss.hitFlash = 6;
        this.spawnParticles(b.x, b.y, b.color, 5, 3);
        hit = true;
        if (this.boss.hp <= 0) this.defeatBoss();
      }
      if (hit && !b.pierce) this.bullets.splice(i, 1);
    }

    // ---- أعداء ----
    const frozen = this.freezeTimer > 0;
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      e.wobble += 0.1;
      if (e.hitFlash > 0) e.hitFlash--;

      if (frozen) continue;

      // ---- اختيار الهدف: أقرب من (اللاعب + الأتباع) ----
      let target = this.player;
      let td = Math.hypot(e.x - this.player.x, e.y - this.player.y);
      for (const f of this.followers) {
        const fd = Math.hypot(e.x - f.x, e.y - f.y);
        if (fd < td) { td = fd; target = f; }
      }
      // الوحوش الرامية قد تفضّل قتال وحش آخر قريب المدى (قتال بين الوحوش)
      if (e.ranged) {
        for (const other of this.enemies) {
          if (other === e || other.ranged) continue;
          const od = Math.hypot(other.x - e.x, other.y - e.y);
          if (od < td && od < e.rangedDistance) { td = od; target = other; }
        }
      }
      const targetR = target.r || 14;

      if (e.ranged) {
        // ---- وحش بعيد المدى: يحافظ على مسافة ويطلق مقذوفات ----
        if (td < CONFIG.ENEMY_LOSE_RANGE + e.rangedDistance) {
          e.state = 'chase';
          if (td > e.rangedDistance + 30) {
            const a = Math.atan2(target.y - e.y, target.x - e.x);
            e.x += Math.cos(a) * e.speed;
            e.y += Math.sin(a) * e.speed;
          } else if (td < e.rangedDistance - 30) {
            const a = Math.atan2(e.y - target.y, e.x - target.x);
            e.x += Math.cos(a) * e.speed * 0.8;
            e.y += Math.sin(a) * e.speed * 0.8;
          }
          if (e.shootTimer === undefined) e.shootTimer = 60;
          e.shootTimer--;
          if (e.shootTimer <= 0) {
            const a = Math.atan2(target.y - e.y, target.x - e.x);
            this.enemyProjectiles.push({
              x: e.x, y: e.y,
              vx: Math.cos(a) * 5, vy: Math.sin(a) * 5,
              r: 7, damage: e.damage, life: 150,
              color: e.projColor, owner: e
            });
            e.shootTimer = 70 + Math.random() * 40;
          }
        } else {
          e.state = 'wander';
          e.wanderTimer--;
          if (e.wanderTimer <= 0) {
            e.wanderAngle = Math.random() * Math.PI * 2;
            e.wanderTimer = 60 + Math.random() * 120;
          }
          e.x += Math.cos(e.wanderAngle) * CONFIG.ENEMY_WANDER_SPEED;
          e.y += Math.sin(e.wanderAngle) * CONFIG.ENEMY_WANDER_SPEED;
        }
      } else if (td < CONFIG.ENEMY_LOSE_RANGE) {
        // ---- وحش قريب المدى: يطارد ----
        e.state = 'chase';
        const a = Math.atan2(target.y - e.y, target.x - e.x);
        e.x += Math.cos(a) * e.speed;
        e.y += Math.sin(a) * e.speed;
      } else {
        e.state = 'wander';
        e.wanderTimer--;
        if (e.wanderTimer <= 0) {
          e.wanderAngle = Math.random() * Math.PI * 2;
          e.wanderTimer = 60 + Math.random() * 120;
        }
        e.x += Math.cos(e.wanderAngle) * CONFIG.ENEMY_WANDER_SPEED;
        e.y += Math.sin(e.wanderAngle) * CONFIG.ENEMY_WANDER_SPEED;
      }

      e.x += Math.cos(e.wobble) * 0.4;
      e.y += Math.sin(e.wobble * 1.3) * 0.4;

      // ---- هجمات قائد المعسكر الخاصة ----
      if (e.isLeader && e.leaderArchetype && e.leaderArchetype.attack !== 'melee_spike') {
        if (e.shootTimer === undefined) e.shootTimer = 90;
        e.shootTimer--;
        if (e.shootTimer <= 0) {
          const a = Math.atan2(target.y - e.y, target.x - e.x);
          const shots = e.leaderArchetype.attack === 'ranged_aoe' ? 3 : 1;
          for (let s = 0; s < shots; s++) {
            const spread = shots > 1 ? (s - (shots - 1) / 2) * 0.35 : 0;
            this.enemyProjectiles.push({
              x: e.x, y: e.y,
              vx: Math.cos(a + spread) * e.leaderArchetype.projSpeed,
              vy: Math.sin(a + spread) * e.leaderArchetype.projSpeed,
              r: 9, damage: Math.round(e.damage * 0.5), life: 180,
              color: e.leaderArchetype.projColor, owner: e
            });
          }
          e.shootTimer = 100 + Math.random() * 40;
        }
      }

      // ---- تصادم مع الهدف (لاعب أو تابع) ----
      if (Math.hypot(target.x - e.x, target.y - e.y) < targetR + e.r) {
        if (target === this.player) this.damagePlayer(e.damage);
        else if (this.followers.includes(target)) this.damageFollower(target, e.damage);
        else {
          // اشتباك بين وحشين (وحش رامٍ يقاتل وحشاً آخر)
          target.hp -= e.damage * 0.2;
          if (target.hp <= 0) this.killEnemy(target);
        }
      }
    }

    // ---- الزعيم ----
    if (this.boss && !frozen) {
      this.boss.wobble += 0.08;
      if (this.boss.hitFlash > 0) this.boss.hitFlash--;
      const angle = Math.atan2(
        this.player.y - this.boss.y,
        this.player.x - this.boss.x
      );
      this.boss.x += Math.cos(angle) * this.boss.speed;
      this.boss.y += Math.sin(angle) * this.boss.speed;

      this.boss.shootTimer--;
      if (this.boss.shootTimer <= 0) {
        this.bossShoot();
        this.boss.shootTimer = Math.max(45, 90 - this.boss.bossLevel * 5);
      }

      if (Math.hypot(this.player.x - this.boss.x, this.player.y - this.boss.y) <
          this.player.r + this.boss.r) {
        this.damagePlayer(this.boss.damage);
      }
    }

    // ---- مقذوفات الزعيم ----
    for (let i = this.bossProjectiles.length - 1; i >= 0; i--) {
      const p = this.bossProjectiles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.life--;
      if (p.life <= 0) { this.bossProjectiles.splice(i, 1); continue; }
      if (Math.hypot(this.player.x - p.x, this.player.y - p.y) < this.player.r + p.r) {
        this.damagePlayer(p.damage);
        this.spawnParticles(p.x, p.y, p.color, 8, 3);
        this.bossProjectiles.splice(i, 1);
      }
    }

    // ---- مقذوفات الأعداء (وحوش بعيدة المدى + قادة المعسكرات) ----
    for (let i = this.enemyProjectiles.length - 1; i >= 0; i--) {
      const p = this.enemyProjectiles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.life--;
      if (p.life <= 0) { this.enemyProjectiles.splice(i, 1); continue; }

      if (Math.hypot(this.player.x - p.x, this.player.y - p.y) < this.player.r + p.r) {
        this.damagePlayer(p.damage);
        this.spawnParticles(p.x, p.y, p.color, 6, 3);
        this.enemyProjectiles.splice(i, 1);
        continue;
      }
      let removed = false;
      for (const f of this.followers) {
        if (Math.hypot(f.x - p.x, f.y - p.y) < f.r + p.r) {
          this.damageFollower(f, p.damage);
          this.spawnParticles(p.x, p.y, p.color, 6, 3);
          this.enemyProjectiles.splice(i, 1);
          removed = true;
          break;
        }
      }
      if (removed) continue;
      // قد يصيب مقذوف الوحش وحشاً آخر (قتال بين الوحوش)
      for (const other of this.enemies) {
        if (other === p.owner) continue;
        if (Math.hypot(other.x - p.x, other.y - p.y) < other.r + p.r) {
          other.hp -= p.damage;
          other.hitFlash = 6;
          this.spawnParticles(p.x, p.y, p.color, 6, 3);
          this.enemyProjectiles.splice(i, 1);
          if (other.hp <= 0) this.killEnemy(other);
          break;
        }
      }
    }

    if (this.player.hitCooldown > 0) this.player.hitCooldown--;

    // ---- أتباع ----
    for (let i = this.followers.length - 1; i >= 0; i--) {
      this.followers[i].update(this);
    }

    // ---- جزيئات ----
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx; p.y += p.vy;
      p.vx *= 0.95; p.vy *= 0.95;
      p.life--;
      if (p.life <= 0) this.particles.splice(i, 1);
    }

    // ---- spawn أعداء قريبين ----
    if (this.enemies.length < 40 + this.level * 2 && !this.boss) {
      if (Math.random() < 0.03) {
        const angle = Math.random() * Math.PI * 2;
        const d = 700 + Math.random() * 400;
        const ex = this.player.x + Math.cos(angle) * d;
        const ey = this.player.y + Math.sin(angle) * d;
        this.enemies.push(createEnemy(ex, ey, this.level));
      }
    }

    // ---- عملات ----
    while (this.coinsArr.length < 20) this.spawnCoinNearPlayer();

    // ---- علب صحة عشوائية ----
    if (this.items.length < 3 && Math.random() < 0.003) {
      const angle = Math.random() * Math.PI * 2;
      const d = 300 + Math.random() * 500;
      this.items.push({
        x: this.player.x + Math.cos(angle) * d,
        y: this.player.y + Math.sin(angle) * d,
        r: 13, heal: 30, pulse: 0
      });
    }
  }

});
