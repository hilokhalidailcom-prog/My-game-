// ===== نظام الأصوات (يولّد كل الأصوات برمجياً بدون ملفات خارجية) =====
const SFX = {
  ctx: null,
  unlocked: false,

  init() {
    if (this.ctx) return;
    try {
      this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    } catch (e) {
      this.ctx = null;
    }
  },

  // يُستدعى عند أول لمسة/ضغطة من المستخدم لفتح الصوت على الموبايل
  unlock() {
    this.init();
    if (!this.ctx) return;
    if (this.ctx.state === 'suspended') this.ctx.resume();
    this.unlocked = true;
  },

  _tone(freq, duration, type, gainStart, freqEnd) {
    if (!this.ctx) return;
    const t0 = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type || 'square';
    osc.frequency.setValueAtTime(freq, t0);
    if (freqEnd) osc.frequency.exponentialRampToValueAtTime(Math.max(20, freqEnd), t0 + duration);
    gain.gain.setValueAtTime(gainStart || 0.2, t0);
    gain.gain.exponentialRampToValueAtTime(0.001, t0 + duration);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(t0);
    osc.stop(t0 + duration + 0.02);
  },

  _noise(duration, gainStart) {
    if (!this.ctx) return;
    const t0 = this.ctx.currentTime;
    const bufferSize = Math.floor(this.ctx.sampleRate * duration);
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
    const src = this.ctx.createBufferSource();
    src.buffer = buffer;
    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(gainStart || 0.2, t0);
    gain.gain.exponentialRampToValueAtTime(0.001, t0 + duration);
    src.connect(gain);
    gain.connect(this.ctx.destination);
    src.start(t0);
  },

  // ===== صوت إطلاق مختلف لكل سلاح =====
  weapon(weaponId) {
    if (!this.ctx) return;
    switch (weaponId) {
      case 'pistol':
        this._tone(520, 0.08, 'square', 0.18, 200);
        break;
      case 'shotgun':
        this._noise(0.14, 0.28);
        this._tone(150, 0.12, 'sawtooth', 0.15, 60);
        break;
      case 'rifle':
        this._tone(700, 0.05, 'square', 0.14, 300);
        break;
      case 'plasma':
        this._tone(220, 0.18, 'sine', 0.2, 700);
        break;
      case 'laser':
        this._tone(1200, 0.09, 'sawtooth', 0.16, 400);
        break;
      case 'minigun':
        this._tone(650, 0.04, 'square', 0.12, 350);
        break;
      default:
        this._tone(400, 0.07, 'square', 0.15, 200);
    }
  },

  hit() { this._tone(180, 0.05, 'triangle', 0.08, 100); },
  explosion() { this._noise(0.25, 0.3); this._tone(90, 0.3, 'sawtooth', 0.2, 30); },
  levelUp() { this._tone(500, 0.15, 'sine', 0.15, 900); },
  heal() { this._tone(700, 0.12, 'sine', 0.12, 1000); }
};
