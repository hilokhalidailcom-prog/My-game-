// ===== نظام الأسلحة =====
const WEAPONS = {
  pistol:  { id: 'pistol',  name: 'مسدس',   damage: 10, cooldown: 22, bulletSpeed: 9,  color: '#ffeb3b', size: 4, spread: 0 },
  shotgun: { id: 'shotgun', name: 'بندقية', damage: 8,  cooldown: 45, bulletSpeed: 8,  color: '#ff9800', size: 4, spread: 0.28, pellets: 5 },
  rifle:   { id: 'rifle',   name: 'رشاش',   damage: 14, cooldown: 12, bulletSpeed: 11, color: '#00e5ff', size: 5, spread: 0.05 },
  plasma:  { id: 'plasma',  name: 'بلازما', damage: 25, cooldown: 30, bulletSpeed: 7,  color: '#e040fb', size: 9, spread: 0 },
  laser:   { id: 'laser',   name: 'ليزر',   damage: 35, cooldown: 18, bulletSpeed: 15, color: '#ff1744', size: 6, spread: 0 },
  minigun: { id: 'minigun', name: 'ميني جن', damage: 12, cooldown: 7,  bulletSpeed: 10, color: '#ffc107', size: 4, spread: 0.12 }
};

const WEAPON_ORDER = ['pistol', 'shotgun', 'rifle', 'plasma', 'laser', 'minigun'];

// تطوير السلاح
const MAX_WEAPON_LEVEL = 10;

function getWeaponStats(weaponId, level) {
  const base = WEAPONS[weaponId];
  const lvl = Math.max(1, level || 1);
  const mult = 1 + (lvl - 1) * 0.25; // +25% لكل مستوى
  const cooldownMult = Math.max(0.4, 1 - (lvl - 1) * 0.06); // أقل cooldown
  const sizeBonus = 1 + (lvl - 1) * 0.08;

  return {
    ...base,
    damage: Math.round(base.damage * mult),
    cooldown: Math.round(base.cooldown * cooldownMult),
    bulletSpeed: base.bulletSpeed + (lvl - 1) * 0.4,
    size: base.size * sizeBonus
  };
}

function getUpgradeCost(weaponId, currentLevel) {
  return {
    coins: 50 * currentLevel * currentLevel,
    points: 20 * currentLevel
  };
}