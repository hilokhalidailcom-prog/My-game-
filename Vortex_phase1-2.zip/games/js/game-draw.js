// ===== رسم كل عناصر اللعبة على الكانفاس =====
Object.assign(Game.prototype, {
  draw() {
    const ctx = this.ctx;

    // خلفية — نستخدم أبعاد الـ canvas الفعلية
    const grad = ctx.createRadialGradient(
      this.W / 2, this.H / 2, 100,
      this.W / 2, this.H / 2, Math.max(this.W, this.H)
    );
    grad.addColorStop(0, '#1e3d1e');
    grad.addColorStop(1, '#0a1a0a');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, this.W, this.H);

    // شبكة
    ctx.strokeStyle = 'rgba(60,120,60,0.15)';
    ctx.lineWidth = 1;
    const gridSize = 100;
    const startX = Math.floor(this.camera.x / gridSize) * gridSize;
    const startY = Math.floor(this.camera.y / gridSize) * gridSize;
    for (let x = startX; x < this.camera.x + this.W + gridSize; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x - this.camera.x, 0);
      ctx.lineTo(x - this.camera.x, this.H);
      ctx.stroke();
    }
    for (let y = startY; y < this.camera.y + this.H + gridSize; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y - this.camera.y);
      ctx.lineTo(this.W, y - this.camera.y);
      ctx.stroke();
    }

    // الأشجار
    for (const chunk of this.world.chunks.values()) {
      for (const t of chunk.trees) {
        const sx = t.x - this.camera.x;
        const sy = t.y - this.camera.y;
        if (sx < -60 || sx > this.W + 60 || sy < -60 || sy > this.H + 60) continue;

        ctx.fillStyle = 'rgba(0,0,0,0.3)';
        ctx.beginPath();
        ctx.ellipse(sx + 6, sy + 8, t.r * 0.9, t.r * 0.4, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#3e2723';
        ctx.fillRect(sx - 4, sy - 5, 8, 18);
        const g = ctx.createRadialGradient(sx - 5, sy - 10, 2, sx, sy - 5, t.r);
        g.addColorStop(0, `rgba(80, ${150 * t.shade + 50}, 60, 1)`);
        g.addColorStop(1, `rgba(20, ${60 * t.shade + 20}, 20, 1)`);
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(sx, sy - 8, t.r, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // المعسكرات
    for (const chunk of this.world.chunks.values()) {
      if (chunk.camp) drawCamp(ctx, chunk.camp, this.camera);
    }

    // عملات
    for (const c of this.coinsArr) {
      const sx = c.x - this.camera.x;
      const sy = c.y - this.camera.y;
      if (sx < -30 || sx > this.W + 30 || sy < -30 || sy > this.H + 30) continue;
      const pulse = Math.sin(c.pulse) * 0.15 + 1;
      const r = c.r * pulse;
      ctx.shadowColor = '#ffd700';
      ctx.shadowBlur = 15;
      const g = ctx.createRadialGradient(sx - 3, sy - 3, 1, sx, sy, r);
      g.addColorStop(0, '#fff59d');
      g.addColorStop(0.6, '#ffd700');
      g.addColorStop(1, '#b8860b');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(sx, sy, r, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.fillStyle = '#8b6914';
      ctx.font = 'bold 12px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('$', sx, sy + 1);
    }

    // علب صحة
    for (const it of this.items) {
      const sx = it.x - this.camera.x;
      const sy = it.y - this.camera.y;
      if (sx < -30 || sx > this.W + 30 || sy < -30 || sy > this.H + 30) continue;
      const pulse = Math.sin(it.pulse) * 0.15 + 1;
      ctx.shadowColor = '#ff69b4';
      ctx.shadowBlur = 15;
      ctx.fillStyle = '#ff69b4';
      ctx.beginPath();
      ctx.arc(sx, sy, it.r * pulse, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 16px Arial';
      ctx.fillText('+', sx, sy + 1);
    }

    // دروع
    for (const a of this.armorDrops) {
      const sx = a.x - this.camera.x;
      const sy = a.y - this.camera.y;
      if (sx < -40 || sx > this.W + 40 || sy < -40 || sy > this.H + 40) continue;
      const pulse = Math.sin(a.pulse) * 0.15 + 1;
      ctx.shadowColor = a.armor.color;
      ctx.shadowBlur = 20;
      ctx.fillStyle = a.armor.color;
      ctx.beginPath();
      ctx.moveTo(sx, sy - a.r * pulse);
      ctx.lineTo(sx + a.r * pulse, sy - a.r * 0.3 * pulse);
      ctx.lineTo(sx + a.r * pulse, sy + a.r * 0.4 * pulse);
      ctx.lineTo(sx, sy + a.r * pulse);
      ctx.lineTo(sx - a.r * pulse, sy + a.r * 0.4 * pulse);
      ctx.lineTo(sx - a.r * pulse, sy - a.r * 0.3 * pulse);
      ctx.closePath();
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.strokeStyle = '#fff';
      ctx.lineWidth = 2;
      ctx.stroke();
    }

    // رصاصات
    for (const b of this.bullets) {
      const sx = b.x - this.camera.x;
      const sy = b.y - this.camera.y;
      if (sx < -20 || sx > this.W + 20 || sy < -20 || sy > this.H + 20) continue;
      ctx.shadowColor = b.color;
      ctx.shadowBlur = 12;
      ctx.fillStyle = b.color;
      ctx.beginPath();
      ctx.arc(sx, sy, b.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    }
    for (const p of this.bossProjectiles) {
      const sx = p.x - this.camera.x;
      const sy = p.y - this.camera.y;
      if (sx < -30 || sx > this.W + 30 || sy < -30 || sy > this.H + 30) continue;
      ctx.shadowColor = p.color;
      ctx.shadowBlur = 15;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(sx, sy, p.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    }
    // مقذوفات الأعداء (وحوش بعيدة المدى + قادة المعسكرات)
    for (const p of this.enemyProjectiles) {
      const sx = p.x - this.camera.x;
      const sy = p.y - this.camera.y;
      if (sx < -30 || sx > this.W + 30 || sy < -30 || sy > this.H + 30) continue;
      ctx.shadowColor = p.color;
      ctx.shadowBlur = 12;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(sx, sy, p.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    }

    // أعداء
    for (const e of this.enemies) {
      const sx = e.x - this.camera.x;
      const sy = e.y - this.camera.y;
      if (sx < -60 || sx > this.W + 60 || sy < -60 || sy > this.H + 60) continue;

      ctx.fillStyle = 'rgba(0,0,0,0.4)';
      ctx.beginPath();
      ctx.ellipse(sx, sy + e.r * 0.8, e.r * 0.8, e.r * 0.3, 0, 0, Math.PI * 2);
      ctx.fill();

      const bodyColor = e.hitFlash > 0 ? '#ffffff' : e.color;
      const g = ctx.createRadialGradient(sx - e.r * 0.3, sy - e.r * 0.3, 2, sx, sy, e.r);
      g.addColorStop(0, bodyColor);
      g.addColorStop(1, '#000000');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(sx, sy, e.r, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#ffff00';
      ctx.beginPath();
      ctx.arc(sx - e.r * 0.35, sy - e.r * 0.2, e.r * 0.18, 0, Math.PI * 2);
      ctx.arc(sx + e.r * 0.35, sy - e.r * 0.2, e.r * 0.18, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#000';
      ctx.beginPath();
      ctx.arc(sx - e.r * 0.35, sy - e.r * 0.2, e.r * 0.08, 0, Math.PI * 2);
      ctx.arc(sx + e.r * 0.35, sy - e.r * 0.2, e.r * 0.08, 0, Math.PI * 2);
      ctx.fill();

      if (e.isLeader) {
        ctx.fillStyle = '#ffd700';
        ctx.beginPath();
        ctx.moveTo(sx - e.r * 0.6, sy - e.r * 0.9);
        ctx.lineTo(sx - e.r * 0.4, sy - e.r * 1.3);
        ctx.lineTo(sx - e.r * 0.15, sy - e.r * 0.95);
        ctx.lineTo(sx, sy - e.r * 1.35);
        ctx.lineTo(sx + e.r * 0.15, sy - e.r * 0.95);
        ctx.lineTo(sx + e.r * 0.4, sy - e.r * 1.3);
        ctx.lineTo(sx + e.r * 0.6, sy - e.r * 0.9);
        ctx.closePath();
        ctx.fill();

        if (e.leaderArchetype) {
          ctx.font = 'bold 13px Arial';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(e.leaderArchetype.icon, sx, sy - e.r - 20);
        }
      }

      // سلاح/عتاد العدو (مظهر فقط)
      if (e.weaponIcon) {
        ctx.font = (e.r * 0.6) + 'px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(e.weaponIcon, sx + e.r * 0.55, sy + e.r * 0.55);
      }

      const hpPct = e.hp / e.maxHp;
      const barW = e.r * 2;
      ctx.fillStyle = 'rgba(0,0,0,0.7)';
      ctx.fillRect(sx - barW/2, sy - e.r - 12, barW, 5);
      ctx.fillStyle = hpPct > 0.5 ? '#4caf50' : hpPct > 0.25 ? '#ff9800' : '#f44336';
      ctx.fillRect(sx - barW/2, sy - e.r - 12, barW * hpPct, 5);
    }

    // زعيم
    if (this.boss) {
      const sx = this.boss.x - this.camera.x;
      const sy = this.boss.y - this.camera.y;
      ctx.shadowColor = '#ff1744';
      ctx.shadowBlur = 30;
      const bodyColor = this.boss.hitFlash > 0 ? '#ffffff' : this.boss.color;
      const g = ctx.createRadialGradient(
        sx - this.boss.r * 0.3, sy - this.boss.r * 0.3, 5,
        sx, sy, this.boss.r
      );
      g.addColorStop(0, bodyColor);
      g.addColorStop(1, '#000000');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(sx, sy, this.boss.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      ctx.fillStyle = '#ffeb3b';
      ctx.beginPath();
      ctx.arc(sx - this.boss.r * 0.35, sy - this.boss.r * 0.2, this.boss.r * 0.2, 0, Math.PI * 2);
      ctx.arc(sx + this.boss.r * 0.35, sy - this.boss.r * 0.2, this.boss.r * 0.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#000';
      ctx.beginPath();
      ctx.arc(sx - this.boss.r * 0.35, sy - this.boss.r * 0.2, this.boss.r * 0.1, 0, Math.PI * 2);
      ctx.arc(sx + this.boss.r * 0.35, sy - this.boss.r * 0.2, this.boss.r * 0.1, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#000';
      ctx.beginPath();
      ctx.arc(sx, sy + this.boss.r * 0.3, this.boss.r * 0.4, 0, Math.PI);
      ctx.fill();

      // شريط صحة الزعيم فوق زر الإطلاق قليلاً
      const finalY = this.H - 60;
      const barW = Math.min(400, this.W - 40);
      const barX = (this.W - barW) / 2;
      ctx.fillStyle = 'rgba(0,0,0,0.8)';
      ctx.fillRect(barX - 3, finalY - 3, barW + 6, 26);
      ctx.fillStyle = '#333';
      ctx.fillRect(barX, finalY, barW, 20);
      const hpPct = this.boss.hp / this.boss.maxHp;
      ctx.fillStyle = '#ff1744';
      ctx.fillRect(barX, finalY, barW * hpPct, 20);
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 13px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(
        '🐲 زعيم — ' + Math.ceil(this.boss.hp) + ' / ' + this.boss.maxHp,
        this.W / 2, finalY + 10
      );
    }

    // أتباع
    for (const f of this.followers) f.draw(ctx, this.camera);

    // جزيئات
    for (let i = 0; i < this.particles.length; i++) {
      const p = this.particles[i];
      const sx = p.x - this.camera.x;
      const sy = p.y - this.camera.y;
      if (sx < -20 || sx > this.W + 20 || sy < -20 || sy > this.H + 20) continue;
      const alpha = p.life / p.maxLife;
      ctx.globalAlpha = alpha;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(sx, sy, p.size * alpha, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;

    // اللاعب
    this.player.draw(ctx, this.camera, this);

    // مؤثرات نشطة
    if (this.freezeTimer > 0) {
      ctx.fillStyle = 'rgba(3,169,244,0.3)';
      ctx.fillRect(0, 0, this.W, this.H);
    }
    if (this.rageTimer > 0) {
      ctx.fillStyle = 'rgba(255,0,0,0.15)';
      ctx.fillRect(0, 0, this.W, this.H);
    }

    // ميني ماب
    try {
      UI.drawMiniMap(this, this.camera, this.W, this.H);
    } catch (err) {
      // تجاهل أي خطأ في المينيماب حتى لا يعطل الرسم
    }
  },

  drawWeaponShape(ctx, weaponId, lvl) {
    const colors = ['#555', '#666', '#777', '#888', '#999', '#aaa', '#bbb', '#ccc', '#ddd', '#fff'];
    const color = colors[Math.min(lvl - 1, colors.length - 1)];
    ctx.fillStyle = color;

    const sizeBonus = 1 + (lvl - 1) * 0.05;

    if (weaponId === 'pistol') {
      ctx.fillRect(10, -3, 16 * sizeBonus, 6);
    } else if (weaponId === 'shotgun') {
      ctx.fillRect(10, -4, 22 * sizeBonus, 8);
      ctx.fillStyle = '#8d6e63';
      ctx.fillRect(8, -5, 6, 10);
    } else if (weaponId === 'rifle') {
      ctx.fillRect(10, -3, 26 * sizeBonus, 6);
      ctx.fillStyle = '#333';
      ctx.fillRect(6, -4, 5, 8);
    } else if (weaponId === 'plasma') {
      ctx.fillStyle = '#7b1fa2';
      ctx.fillRect(8, -5, 20 * sizeBonus, 10);
      ctx.fillStyle = '#e040fb';
      ctx.beginPath();
      ctx.arc(30 * sizeBonus, 0, 5, 0, Math.PI * 2);
      ctx.fill();
    } else if (weaponId === 'laser') {
      ctx.fillStyle = '#c62828';
      ctx.fillRect(10, -3, 28 * sizeBonus, 6);
      ctx.fillStyle = '#ff1744';
      ctx.beginPath();
      ctx.arc(38 * sizeBonus, 0, 4, 0, Math.PI * 2);
      ctx.fill();
    } else if (weaponId === 'minigun') {
      ctx.fillStyle = '#555';
      ctx.fillRect(10, -6, 24 * sizeBonus, 12);
      ctx.fillStyle = '#333';
      for (let i = 0; i < 3; i++) {
        ctx.fillRect(30 * sizeBonus, -5 + i * 4, 8, 2);
      }
    }

    if (lvl >= 5) {
      ctx.strokeStyle = '#ffd700';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(20, 0, 15 * sizeBonus, 0, Math.PI * 2);
      ctx.stroke();
    }
  }

});
