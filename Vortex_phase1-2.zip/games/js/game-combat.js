// ===== قتال وتقدّم اللاعب (إطلاق النار، رفع المستوى، الزعيم) =====
Object.assign(Game.prototype, {
  // ===== إطلاق النار =====
  shoot() {
    if (this.shootTimer > 0) return;
    const w = getWeaponStats(this.currentWeapon, this.weaponLevels[this.currentWeapon] || 1);
    this.shootTimer = w.cooldown;

    const rageMulti = this.rageTimer > 0 ? 3 : 1;

    // الاتجاه يعتمد فقط على اتجاه عصا التحريك (يُحدَّث في update())، وليس على أقرب عدو
    const targetAngle = this.player.aimAngle;

    SFX.weapon(this.currentWeapon);

    const pellets = w.pellets || 1;
    for (let i = 0; i < pellets; i++) {
      let angle = targetAngle;
      if (pellets > 1) angle += (i - (pellets - 1) / 2) * w.spread;
      else angle += (Math.random() - 0.5) * w.spread * 2;

      this.bullets.push({
        x: this.player.x + Math.cos(angle) * (this.player.r + 4),
        y: this.player.y + Math.sin(angle) * (this.player.r + 4),
        vx: Math.cos(angle) * w.bulletSpeed,
        vy: Math.sin(angle) * w.bulletSpeed,
        r: w.size, damage: w.damage * rageMulti,
        color: w.color, life: 150,
        pierce: this.weaponLevels[this.currentWeapon] >= 5
      });
    }
    this.spawnParticles(
      this.player.x + Math.cos(targetAngle) * 20,
      this.player.y + Math.sin(targetAngle) * 20,
      '#ffff00', 3, 2
    );
  },

  // ===== ترقية المستوى =====
  levelUp() {
    SFX.levelUp();
    this.level++;
    this.coinsForNextLevel += 10;
    this.player.maxHealth += 10;
    this.player.health = Math.min(this.player.health + 25, this.player.maxHealth);
    this.points += 20;

    let unlocked = null;
    if (this.level === 2 && !this.unlockedWeapons.includes('shotgun')) unlocked = 'shotgun';
    else if (this.level === 3 && !this.unlockedWeapons.includes('rifle')) unlocked = 'rifle';
    else if (this.level === 5 && !this.unlockedWeapons.includes('plasma')) unlocked = 'plasma';
    else if (this.level === 7 && !this.unlockedWeapons.includes('laser')) unlocked = 'laser';
    else if (this.level === 10 && !this.unlockedWeapons.includes('minigun')) unlocked = 'minigun';

    if (unlocked) {
      this.unlockedWeapons.push(unlocked);
      this.weaponLevels[unlocked] = 1;
      this.currentWeapon = unlocked;
      UI.showLevelMsg('🎉 المستوى ' + this.level + ' — ' + WEAPONS[unlocked].name + '!');
    } else {
      UI.showLevelMsg('🎉 المستوى ' + this.level + '!');
    }

    if (this.level % 10 === 0 && this.level !== this.lastBossLevel) {
      this.lastBossLevel = this.level;
      this.spawnBoss();
    }

    UI.updateHUD(this);
  },

  spawnBoss() {
    const bossLevel = Math.floor(this.level / 10);
    const angle = Math.random() * Math.PI * 2;
    const dist = 700;
    const x = this.player.x + Math.cos(angle) * dist;
    const y = this.player.y + Math.sin(angle) * dist;
    this.boss = createBoss(x, y, bossLevel);
    UI.showBossWarning('⚠️ زعيم! ⚠️');
  },

  bossShoot() {
    if (!this.boss) return;
    const count = 6 + this.boss.bossLevel * 2;
    const baseAngle = Math.atan2(
      this.player.y - this.boss.y,
      this.player.x - this.boss.x
    );
    for (let i = 0; i < count; i++) {
      const angle = baseAngle + (i / count) * Math.PI * 2;
      this.bossProjectiles.push({
        x: this.boss.x, y: this.boss.y,
        vx: Math.cos(angle) * 3.5,
        vy: Math.sin(angle) * 3.5,
        r: 8, damage: 12 + this.boss.bossLevel * 3,
        life: 200, color: '#ff1744'
      });
    }
  },

  defeatBoss() {
    this.spawnParticles(this.boss.x, this.boss.y, '#ff1744', 40, 8);
    this.spawnParticles(this.boss.x, this.boss.y, '#ffd700', 30, 6);

    for (let i = 0; i < 20; i++) {
      const angle = Math.random() * Math.PI * 2;
      const d = Math.random() * 100;
      this.coinsArr.push({
        x: this.boss.x + Math.cos(angle) * d,
        y: this.boss.y + Math.sin(angle) * d,
        r: 12, pulse: 0
      });
    }

    const armorIdx = Math.min(this.boss.bossLevel, ARMOR_TYPES.length - 1);
    const armorType = ARMOR_TYPES[armorIdx];
    this.armorDrops.push({
      x: this.boss.x, y: this.boss.y,
      r: 20,
      armor: { ...armorType, hp: armorType.maxHp },
      pulse: 0
    });

    const newWeapons = WEAPON_ORDER.filter(w => !this.unlockedWeapons.includes(w));
    if (newWeapons.length > 0) {
      const nw = newWeapons[0];
      this.unlockedWeapons.push(nw);
      this.weaponLevels[nw] = 1;
      this.currentWeapon = nw;
      UI.showLevelMsg('🔫 حصلت على ' + WEAPONS[nw].name + '!');
    }

    this.points += 100;
    this.items.push({
      x: this.boss.x + 40, y: this.boss.y + 40,
      r: 15, heal: 60, pulse: 0
    });

    this.boss = null;
    this.bossProjectiles = [];
  },

  // ===== إصابة اللاعب =====
  damagePlayer(amount) {
    if (this.player.hitCooldown > 0) return;

    if (this.player.armor) {
      const absorbed = amount * this.player.armor.reduction;
      const toHealth = amount - absorbed;
      this.player.armor.hp -= absorbed;
      this.player.health -= toHealth;
      this.spawnParticles(this.player.x, this.player.y, this.player.armor.color, 8, 3);
      if (this.player.armor.hp <= 0) {
        this.spawnParticles(this.player.x, this.player.y, this.player.armor.color, 15, 4);
        UI.showNotification('🛡️ انكسر ' + this.player.armor.name);
        this.player.armor = null;
      }
    } else {
      this.player.health -= amount;
      this.spawnParticles(this.player.x, this.player.y, '#ff0000', 8, 4);
    }

    this.player.hitCooldown = 30;
    UI.updateHUD(this);
    if (this.player.health <= 0) this.gameOver();
  },

  // ===== إصابة تابع =====
  damageFollower(f, amount) {
    f.hp -= amount;
    f.hitFlash = 8;
    this.spawnParticles(f.x, f.y, f.type.color, 6, 3);
    if (f.hp <= 0) {
      this.spawnParticles(f.x, f.y, f.type.color, 20, 5);
      UI.showNotification('💀 مات ' + f.type.name);
      const idx = this.followers.indexOf(f);
      if (idx !== -1) this.followers.splice(idx, 1);
    }
  },

  // ===== إصابة أي هدف (عدو أو زعيم) — تُستخدم من الأتباع =====
  applyDamageToTarget(target, amount) {
    if (target === this.boss) {
      target.hp -= amount;
      target.hitFlash = 6;
      if (target.hp <= 0) this.defeatBoss();
    } else {
      target.hp -= amount;
      target.hitFlash = 6;
      if (target.hp <= 0) this.killEnemy(target);
    }
  },

  // ===== موت عدو: جزيئات + عملات + نقاط + غنيمة (تتناسب مع قوة العدو) + تنظيف المعسكر =====
  killEnemy(e) {
    this.spawnParticles(e.x, e.y, e.color, 18, 5);
    this.coins++;
    this.points += CONFIG.POINTS_PER_KILL;

    // قوة العدو (tier) تحدد كمية ونوعية الغنيمة
    const typeCfg = CONFIG.ENEMY_TYPES.find(t => t.id === e.typeId);
    const tier = typeCfg ? typeCfg.hpMul : 1;

    if (Math.random() < 0.6) {
      const coinDrops = 1 + Math.floor(tier);
      for (let k = 0; k < coinDrops; k++) {
        const ang = Math.random() * Math.PI * 2;
        const dd = Math.random() * 20;
        this.coinsArr.push({
          x: e.x + Math.cos(ang) * dd,
          y: e.y + Math.sin(ang) * dd,
          r: 12, pulse: 0
        });
      }
    }

    const itemChance = CONFIG.ITEM_DROP_CHANCE * (1 + tier * 0.5);
    if (Math.random() < itemChance) {
      this.items.push({ x: e.x, y: e.y, r: 13, heal: 25, pulse: 0 });
    }

    if (tier >= 2 && Math.random() < 0.05 * tier) {
      const armorIdx = Math.min(Math.floor(tier), ARMOR_TYPES.length - 1);
      const armorType = ARMOR_TYPES[armorIdx];
      this.armorDrops.push({
        x: e.x, y: e.y, r: 20,
        armor: { ...armorType, hp: armorType.maxHp },
        pulse: 0
      });
    }

    for (const chunk of this.world.chunks.values()) {
      if (chunk.camp && chunk.camp.enemies) {
        const idx = chunk.camp.enemies.indexOf(e);
        if (idx !== -1) {
          chunk.camp.enemies.splice(idx, 1);
          if (chunk.camp.enemies.length === 0 && !chunk.camp.leader) {
            chunk.camp.cleared = true;
            this.points += 50;
            UI.showNotification('🏆 تم تنظيف المعسكر!');
          }
        }
      }
    }

    const idx2 = this.enemies.indexOf(e);
    if (idx2 !== -1) this.enemies.splice(idx2, 1);
  }

});
