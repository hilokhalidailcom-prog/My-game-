// ===== نظام الدروع =====
const ARMOR_TYPES = [
  { name: 'درع خشبي',   maxHp: 40,  reduction: 0.30, color: '#8d6e63', tier: 1 },
  { name: 'درع حديدي',  maxHp: 80,  reduction: 0.50, color: '#b0bec5', tier: 2 },
  { name: 'درع ذهبي',   maxHp: 130, reduction: 0.65, color: '#ffd700', tier: 3 },
  { name: 'درع أسطوري', maxHp: 200, reduction: 0.80, color: '#e040fb', tier: 4 },
  { name: 'درع التنين', maxHp: 320, reduction: 0.90, color: '#ff6f00', tier: 5 }
];

function getArmorByTier(tier) {
  return ARMOR_TYPES[Math.min(tier - 1, ARMOR_TYPES.length - 1)];
}