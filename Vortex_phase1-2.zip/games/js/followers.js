// ===== نظام الأتباع =====
// كل تابع له "behavior" يحدد طريقة قتاله:
//   ranged        : يطلق رصاصة على أقرب عدو (الافتراضي)
//   ranged_far    : مثل ranged لكن يبقى بعيد عن اللاعب
//   stationary_ranged : يثبت في مكان بعيد ويقنص
//   heal          : يشفي اللاعب
//   melee         : يضرب عند الاقتراب (بدون رصاص)
//   trample       : يتحرك نحو العدو مباشرة ويدهسه
//   aoe           : ينفث ضرر دائري حوله
//   explosive     : يرمي مقذوف ينفجر
//   flame         : مثل ranged لكن لون اللهب يتغير مع المستوى
//   rescue        : ينقذ اللاعب لو انحاصر بين أعداء
const FOLLOWER_TYPES = {
  guard: {
    id: 'guard', name: 'حارس', icon: '🛡️', color: '#2196f3',
    hp: 80, damage: 15, speed: 2.5, range: 250, cooldown: 40, price: 150,
    behavior: 'ranged',
    desc: 'يحرسك ويطلق على الأعداء'
  },
  archer: {
    id: 'archer', name: 'رامي', icon: '🏹', color: '#4caf50',
    hp: 50, damage: 25, speed: 2.8, range: 400, cooldown: 30, price: 250,
    behavior: 'ranged',
    desc: 'رامي بعيد المدى، ضرر عالي'
  },
  mage: {
    id: 'mage', name: 'ساحر', icon: '🔮', color: '#9c27b0',
    hp: 40, damage: 40, speed: 2.2, range: 350, cooldown: 60, price: 400,
    behavior: 'ranged',
    desc: 'يطلق كرات سحرية قوية'
  },
  healer: {
    id: 'healer', name: 'معالج', icon: '💚', color: '#8bc34a',
    hp: 60, damage: 0, speed: 2.6, range: 300, cooldown: 120, price: 350,
    behavior: 'heal',
    desc: 'يشفي صحتك 10 كل فترة'
  },
  knight: {
    id: 'knight', name: 'فارس', icon: '⚔️', color: '#795548',
    hp: 200, damage: 35, speed: 2.0, range: 200, cooldown: 35, price: 600,
    behavior: 'ranged',
    desc: 'محارب قوي قريب المدى'
  },
  dragon_pet: {
    id: 'dragon_pet', name: 'تنين صغير', icon: '🐉', color: '#ff6f00',
    hp: 150, damage: 60, speed: 3.0, range: 400, cooldown: 50, price: 1200,
    behavior: 'ranged',
    desc: 'تنين يطلق النار بضرر عالي'
  },
  // ===== أنواع جديدة =====
  dragon_ring: {
    id: 'dragon_ring', name: 'التنين', icon: '🐲', color: '#d84315',
    hp: 180, damage: 16, speed: 2.0, range: 0, cooldown: 70, price: 900,
    behavior: 'aoe',
    desc: 'ينفث حلقة نار تحرق كل الأعداء القريبين منه'
  },
  rescuer: {
    id: 'rescuer', name: 'المنقذ', icon: '🆘', color: '#00bcd4',
    hp: 70, damage: 0, speed: 3.4, range: 130, cooldown: 240, price: 500,
    behavior: 'rescue',
    desc: 'إذا انحصرت بين الأعداء يطلعك منهم بسرعة'
  },
  flamer: {
    id: 'flamer', name: 'رامي اللهب', icon: '🔥', color: '#ff6d00',
    hp: 90, damage: 18, speed: 2.4, range: 220, cooldown: 20, price: 450,
    behavior: 'flame',
    desc: 'يرمي لهب على الأعداء، لونه يتغير كل ما طوّرته'
  },
  hunter: {
    id: 'hunter', name: 'الصياد', icon: '🎯', color: '#33691e',
    hp: 55, damage: 22, speed: 2.6, range: 380, cooldown: 35, price: 300,
    behavior: 'ranged_far',
    desc: 'يبقى بعيد عنك ويصطاد الأعداء القريبين منك'
  },
  sniper: {
    id: 'sniper', name: 'القناص', icon: '🔭', color: '#37474f',
    hp: 45, damage: 70, speed: 1.8, range: 550, cooldown: 100, price: 700,
    behavior: 'stationary_ranged',
    desc: 'يتمركز بعيد جداً ويصيب الأعداء بطلقات قوية'
  },
  duck: {
    id: 'duck', name: 'البطة المهاجمة', icon: '🦆', color: '#fdd835',
    hp: 70, damage: 20, speed: 2.5, range: 300, cooldown: 55, price: 350,
    behavior: 'explosive',
    desc: 'ترمي بيض ينفجر بالأعداء، ويكبر الانفجار كل ما طورتها'
  },
  boxer: {
    id: 'boxer', name: 'الملاكم', icon: '🥊', color: '#d32f2f',
    hp: 140, damage: 30, speed: 2.7, range: 46, cooldown: 25, price: 400,
    behavior: 'melee',
    desc: 'يضرب الأعداء بالبوكسات عن قرب'
  },
  elephant: {
    id: 'elephant', name: 'الفيل', icon: '🐘', color: '#78909c',
    hp: 260, damage: 45, speed: 1.5, range: 55, cooldown: 30, price: 800,
    behavior: 'trample',
    desc: 'يدهس الأعداء بأقدامه، صحة عالية جداً'
  }
};

const MAX_FOLLOWER_LEVEL = 10;

// إحصائيات التابع حسب مستواه (تتضاعف تقريباً عند المستوى 10)
function getFollowerStats(type, level) {
  const lvl = Math.max(1, Math.min(level, MAX_FOLLOWER_LEVEL));
  const dmgMult = 1 + (lvl - 1) * (1 / 9);        // ×1 عند المستوى 1 → ×2 عند المستوى 10
  const hpMult = 1 + (lvl - 1) * (1 / 9) * 1.4;    // صحة تكبر أسرع شوي من الضرر
  return {
    damage: Math.round(type.damage * dmgMult),
    hp: Math.round(type.hp * hpMult),
    range: Math.round(type.range * (1 + (lvl - 1) * 0.03)),
    cooldown: Math.max(8, Math.round(type.cooldown * (1 - (lvl - 1) * 0.045)))
  };
}

function getFollowerUpgradeCost(currentLevel) {
  return {
    coins: 80 * currentLevel * currentLevel,
    points: 12 * currentLevel
  };
}

// ألوان اللهب حسب مستوى "رامي اللهب"
function flameColorForLevel(level) {
  const colors = ['#ffca28', '#ff9800', '#ff6d00', '#ff3d00', '#e64a19', '#d500f9', '#651fff', '#2979ff', '#00e5ff', '#ffffff'];
  return colors[Math.min(level - 1, colors.length - 1)];
}

class Follower {
  constructor(typeId, x, y) {
    const type = FOLLOWER_TYPES[typeId];
    this.id = Math.random().toString(36).substr(2, 9);
    this.typeId = typeId;
    this.type = type;
    this.level = 1;
    this.x = x;
    this.y = y;
    this.r = 14;
    this.applyStats();
    this.hp = this.maxHp;
    this.cooldown = 0;
    this.hitFlash = 0;
    this.wobble = Math.random() * Math.PI * 2;
    this.rescueCooldown = 0;
    this._ringRadius = 0;
    this._ringTimer = 0;
  }

  // يعيد حساب صحة/ضرر/مدى/سرعة إطلاق التابع حسب مستواه الحالي
  applyStats() {
    const s = getFollowerStats(this.type, this.level);
    this.maxHp = s.hp;
    this.damage = s.damage;
    this.range = s.range || 260; // الأتباع بلا مدى محدد (مثل التنين) يستخدمون قيمة افتراضية داخلية
    this.cooldownBase = s.cooldown;
  }

  update(game) {
    if (this.cooldown > 0) this.cooldown--;
    if (this.hitFlash > 0) this.hitFlash--;
    if (this.rescueCooldown > 0) this.rescueCooldown--;
    if (this._ringTimer > 0) this._ringTimer--;
    this.wobble += 0.1;

    const player = game.player;
    const behavior = this.type.behavior || 'ranged';

    // ===== المنقذ: تفقّد إذا اللاعب محاصر =====
    if (behavior === 'rescue') {
      this.handleRescue(game);
    }

    // ===== الحركة (كل الأنواع عدا الدهّاس تتبع اللاعب بمسافة) =====
    if (behavior !== 'trample') {
      let targetDist = 60 + Math.random() * 20;
      if (behavior === 'stationary_ranged') targetDist = this.range * 0.85;
      else if (behavior === 'ranged_far') targetDist = 170 + Math.random() * 40;

      const dx = player.x - this.x;
      const dy = player.y - this.y;
      const d = Math.hypot(dx, dy);
      if (d > targetDist) {
        const sp = this.type.speed;
        this.x += (dx / d) * sp;
        this.y += (dy / d) * sp;
      } else if (d < targetDist - 20) {
        this.x -= (dx / d) * this.type.speed * 0.5;
        this.y -= (dy / d) * this.type.speed * 0.5;
      }
      this.x += Math.cos(this.wobble) * 0.3;
      this.y += Math.sin(this.wobble * 1.3) * 0.3;
    }

    // ===== المعالج =====
    if (behavior === 'heal') {
      if (this.cooldown <= 0 && game.player.health < game.player.maxHealth) {
        game.player.health = Math.min(game.player.health + 10, game.player.maxHealth);
        game.spawnParticles(this.x, this.y, '#8bc34a', 8, 3);
        this.cooldown = this.cooldownBase;
        UI.updateHUD(game);
      }
      return;
    }

    // ===== إيجاد أقرب هدف (عدو أو الزعيم) =====
    let target = null;
    let nd = this.range || 260;
    for (const e of game.enemies) {
      const dist = Math.hypot(e.x - this.x, e.y - this.y);
      if (dist < nd) { nd = dist; target = e; }
    }
    if (game.boss) {
      const dist = Math.hypot(game.boss.x - this.x, game.boss.y - this.y);
      if (dist < nd) { nd = dist; target = game.boss; }
    }

    // ===== الدهّاس (فيل): يتحرك للعدو مباشرة ويدهسه =====
    if (behavior === 'trample') {
      if (target) {
        const a = Math.atan2(target.y - this.y, target.x - this.x);
        this.x += Math.cos(a) * this.type.speed;
        this.y += Math.sin(a) * this.type.speed;
        if (nd < this.r + (target.r || 20) + 10 && this.cooldown <= 0) {
          game.applyDamageToTarget(target, this.damage);
          game.spawnParticles(target.x, target.y, '#795548', 10, 3);
          this.cooldown = this.cooldownBase;
        }
      } else {
        const dx = player.x - this.x, dy = player.y - this.y, d = Math.hypot(dx, dy);
        if (d > 120) { this.x += (dx / d) * this.type.speed; this.y += (dy / d) * this.type.speed; }
      }
      return;
    }

    // ===== ملاكم =====
    if (behavior === 'melee') {
      if (target && nd < this.r + (target.r || 20) + 8 && this.cooldown <= 0) {
        game.applyDamageToTarget(target, this.damage);
        game.spawnParticles(target.x, target.y, this.type.color, 8, 3);
        this.cooldown = this.cooldownBase;
      }
      return;
    }

    // ===== التنين (حلقة نار) =====
    if (behavior === 'aoe') {
      if (this.cooldown <= 0) {
        const radius = 90 + this.level * 6;
        let hitAny = false;
        for (const e of game.enemies) {
          if (Math.hypot(e.x - this.x, e.y - this.y) < radius) {
            game.applyDamageToTarget(e, this.damage);
            hitAny = true;
          }
        }
        if (game.boss && Math.hypot(game.boss.x - this.x, game.boss.y - this.y) < radius) {
          game.applyDamageToTarget(game.boss, this.damage);
          hitAny = true;
        }
        if (hitAny) game.spawnParticles(this.x, this.y, '#ff6f00', 16, 4);
        this._ringRadius = radius;
        this._ringTimer = 14;
        this.cooldown = this.cooldownBase;
      }
      return;
    }

    // ===== البطة المهاجمة: بيض متفجر =====
    if (behavior === 'explosive') {
      if (target && this.cooldown <= 0) {
        const angle = Math.atan2(target.y - this.y, target.x - this.x);
        game.bullets.push({
          x: this.x, y: this.y,
          vx: Math.cos(angle) * 6, vy: Math.sin(angle) * 6,
          r: 7, damage: this.damage, color: '#fff9c4', life: 90,
          fromFollower: true, explosive: true, explosionRadius: 40 + this.level * 6
        });
        this.cooldown = this.cooldownBase;
      }
      return;
    }

    // ===== باقي الأنواع: رصاصة عادية (ranged / ranged_far / stationary_ranged / flame) =====
    if (target && this.cooldown <= 0) {
      const angle = Math.atan2(target.y - this.y, target.x - this.x);
      const color = behavior === 'flame' ? flameColorForLevel(this.level) : this.type.color;
      game.bullets.push({
        x: this.x + Math.cos(angle) * 15,
        y: this.y + Math.sin(angle) * 15,
        vx: Math.cos(angle) * 10,
        vy: Math.sin(angle) * 10,
        r: 5, damage: this.damage,
        color,
        life: 120,
        fromFollower: true
      });
      this.cooldown = this.cooldownBase;
    }
  }

  // ينقذ اللاعب إذا كان محاصراً بعدد كافٍ من الأعداء القريبين
  handleRescue(game) {
    if (this.rescueCooldown > 0) return;
    const player = game.player;
    let count = 0, sumX = 0, sumY = 0;
    for (const e of game.enemies) {
      const d = Math.hypot(e.x - player.x, e.y - player.y);
      if (d < 90) { count++; sumX += e.x; sumY += e.y; }
    }
    if (count >= 3) {
      const awayAngle = Math.atan2(player.y - sumY / count, player.x - sumX / count);
      const dashDist = 160;
      player.x += Math.cos(awayAngle) * dashDist;
      player.y += Math.sin(awayAngle) * dashDist;
      this.x = player.x - Math.cos(awayAngle) * 30;
      this.y = player.y - Math.sin(awayAngle) * 30;
      game.spawnParticles(player.x, player.y, '#00bcd4', 20, 5);
      UI.showNotification('🆘 المنقذ سحبك من الحصار!');
      this.rescueCooldown = 240;
    }
  }

  draw(ctx, camera) {
    const sx = this.x - camera.x;
    const sy = this.y - camera.y;

    // حلقة نار "التنين" أثناء الهجوم
    if (this._ringTimer > 0 && this._ringRadius > 0) {
      ctx.strokeStyle = 'rgba(255,111,0,' + (this._ringTimer / 14) + ')';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(sx, sy, this._ringRadius, 0, Math.PI * 2);
      ctx.stroke();
    }

    ctx.fillStyle = 'rgba(0,0,0,0.4)';
    ctx.beginPath();
    ctx.ellipse(sx, sy + this.r * 0.8, this.r * 0.8, this.r * 0.3, 0, 0, Math.PI * 2);
    ctx.fill();

    // هالة
    ctx.strokeStyle = this.type.color;
    ctx.lineWidth = 2;
    ctx.globalAlpha = 0.6;
    ctx.beginPath();
    ctx.arc(sx, sy, this.r + 4, 0, Math.PI * 2);
    ctx.stroke();
    ctx.globalAlpha = 1;

    // جسم
    const bodyColor = this.hitFlash > 0 ? '#fff' : this.type.color;
    const g = ctx.createRadialGradient(sx - 4, sy - 4, 2, sx, sy, this.r);
    g.addColorStop(0, bodyColor);
    g.addColorStop(1, '#000');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(sx, sy, this.r, 0, Math.PI * 2);
    ctx.fill();

    // أيقونة
    ctx.font = 'bold 14px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(this.type.icon, sx, sy);

    // ===== عتاد إضافي يظهر كل ما زاد المستوى =====
    const plates = Math.floor((this.level - 1) / 3); // 0..3 صفائح درع
    for (let p = 0; p < plates; p++) {
      const ang = (Math.PI * 2 / 3) * p + this.wobble * 0.2;
      const px = sx + Math.cos(ang) * (this.r + 7);
      const py = sy + Math.sin(ang) * (this.r + 7);
      ctx.fillStyle = '#ffd54f';
      ctx.beginPath();
      ctx.arc(px, py, 3.5, 0, Math.PI * 2);
      ctx.fill();
    }
    if (this.level >= 10) {
      ctx.strokeStyle = '#ffd700';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(sx, sy, this.r + 9, 0, Math.PI * 2);
      ctx.stroke();
    }

    // رقم المستوى
    ctx.fillStyle = '#000';
    ctx.font = 'bold 9px Arial';
    ctx.fillText(this.level, sx + this.r - 3, sy - this.r + 3);

    // شريط صحة
    const hpPct = this.hp / this.maxHp;
    if (hpPct < 1) {
      ctx.fillStyle = 'rgba(0,0,0,0.7)';
      ctx.fillRect(sx - 15, sy - this.r - 10, 30, 4);
      ctx.fillStyle = '#4caf50';
      ctx.fillRect(sx - 15, sy - this.r - 10, 30 * hpPct, 4);
    }
  }
}
