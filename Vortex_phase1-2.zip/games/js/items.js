// ===== نظام الأدوات =====
const ITEM_TYPES = {
  health_small: {
    id: 'health_small',
    name: 'جرعة صحة صغيرة',
    icon: '❤️',
    color: '#ff69b4',
    desc: 'تشفي 25 صحة فوراً',
    price: 30,
    use: (game) => {
      game.player.health = Math.min(game.player.health + 25, game.player.maxHealth);
      return 'شُفيت 25 صحة';
    }
  },
  health_big: {
    id: 'health_big',
    name: 'جرعة صحة كبيرة',
    icon: '💗',
    color: '#e91e63',
    desc: 'تشفي 75 صحة',
    price: 80,
    use: (game) => {
      game.player.health = Math.min(game.player.health + 75, game.player.maxHealth);
      return 'شُفيت 75 صحة';
    }
  },
  bomb: {
    id: 'bomb',
    name: 'قنبلة',
    icon: '💣',
    color: '#ff5722',
    desc: 'تقتل كل الأعداء حولك في نطاق 250',
    price: 120,
    use: (game) => {
      let killed = 0;
      for (let i = game.enemies.length - 1; i >= 0; i--) {
        const e = game.enemies[i];
        if (Math.hypot(e.x - game.player.x, e.y - game.player.y) < 250) {
          game.spawnParticles(e.x, e.y, '#ff5722', 15, 5);
          game.enemies.splice(i, 1);
          game.coins += 1;
          game.points += CONFIG.POINTS_PER_KILL;
          killed++;
        }
      }
      return 'انفجرت! قتلت ' + killed + ' عدو';
    }
  },
  freeze: {
    id: 'freeze',
    name: 'تجميد',
    icon: '❄️',
    color: '#03a9f4',
    desc: 'يجمّد كل الأعداء لـ 5 ثواني',
    price: 100,
    use: (game) => {
      game.freezeTimer = 300; // 5 ثواني × 60fps
      return 'تم تجميد الأعداء!';
    }
  },
  rage: {
    id: 'rage',
    name: 'غضب',
    icon: '🔥',
    color: '#f44336',
    desc: 'يضاعف الضرر 3 مرات لـ 10 ثواني',
    price: 150,
    use: (game) => {
      game.rageTimer = 600;
      return 'وضع الغضب نشط!';
    }
  },
  magnet: {
    id: 'magnet',
    name: 'مغناطيس',
    icon: '🧲',
    color: '#9c27b0',
    desc: 'يسحب كل العملات القريبة نحوك',
    price: 60,
    use: (game) => {
      let count = 0;
      for (const c of game.coinsArr) {
        if (Math.hypot(c.x - game.player.x, c.y - game.player.y) < 600) {
          c.x = game.player.x;
          c.y = game.player.y;
          count++;
        }
      }
      return 'سحبت ' + count + ' عملة';
    }
  },
  shield_kit: {
    id: 'shield_kit',
    name: 'عدة إصلاح الدرع',
    icon: '🛠️',
    color: '#42a5f5',
    desc: 'يصلح درعك بالكامل',
    price: 90,
    use: (game) => {
      if (game.player.armor) {
        game.player.armor.hp = game.player.armor.maxHp;
        return 'تم إصلاح الدرع!';
      }
      return 'لا يوجد درع لإصلاحه';
    }
  }
};