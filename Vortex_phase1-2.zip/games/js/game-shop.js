// ===== المتجر، الأدوات، الترقيات، بداية/نهاية اللعبة =====
Object.assign(Game.prototype, {
  // ===== استعمال أداة =====
  useItem(itemId) {
    if (!this.inventory[itemId] || this.inventory[itemId] <= 0) {
      UI.showNotification('❌ لا تملك هذه الأداة');
      return;
    }
    const item = ITEM_TYPES[itemId];
    if (!item) return;

    const msg = item.use(this);
    this.inventory[itemId]--;
    if (this.inventory[itemId] <= 0) delete this.inventory[itemId];

    UI.showNotification(item.icon + ' ' + msg);
    UI.updateHUD(this);
  },

  addItem(itemId, count = 1) {
    this.inventory[itemId] = (this.inventory[itemId] || 0) + count;
  },

  buyFollower(typeId, price) {
    if (this.coins < price) {
      UI.showNotification('❌ عملات غير كافية');
      return false;
    }
    this.coins -= price;
    const angle = Math.random() * Math.PI * 2;
    const f = new Follower(
      typeId,
      this.player.x + Math.cos(angle) * 60,
      this.player.y + Math.sin(angle) * 60
    );
    this.followers.push(f);
    UI.showNotification('✅ ' + FOLLOWER_TYPES[typeId].name + ' انضم إليك!');
    UI.updateHUD(this);
    return true;
  },

  // ===== تطوير تابع حتى المستوى 10 =====
  upgradeFollower(followerId) {
    const f = this.followers.find(x => x.id === followerId);
    if (!f) return false;
    if (f.level >= MAX_FOLLOWER_LEVEL) {
      UI.showNotification('❌ التابع بأقصى مستوى');
      return false;
    }
    const cost = getFollowerUpgradeCost(f.level);
    if (this.coins < cost.coins || this.points < cost.points) {
      UI.showNotification('❌ موارد غير كافية');
      return false;
    }
    this.coins -= cost.coins;
    this.points -= cost.points;
    const oldMax = f.maxHp;
    f.level++;
    f.applyStats();
    f.hp += (f.maxHp - oldMax);
    UI.showNotification('⚒️ ' + f.type.name + ' Lv.' + f.level + '!');
    UI.updateHUD(this);
    return true;
  },

  buyItem(itemId, price) {
    if (this.coins < price) {
      UI.showNotification('❌ عملات غير كافية');
      return false;
    }
    this.coins -= price;
    this.addItem(itemId, 1);
    UI.showNotification('✅ اشتريت ' + ITEM_TYPES[itemId].name);
    UI.updateHUD(this);
    return true;
  },

  upgradeWeapon(weaponId) {
    const currentLevel = this.weaponLevels[weaponId] || 1;
    if (currentLevel >= MAX_WEAPON_LEVEL) {
      UI.showNotification('❌ السلاح بأقصى مستوى');
      return false;
    }
    const cost = getUpgradeCost(weaponId, currentLevel);
    if (this.coins < cost.coins || this.points < cost.points) {
      UI.showNotification('❌ موارد غير كافية');
      return false;
    }
    this.coins -= cost.coins;
    this.points -= cost.points;
    this.weaponLevels[weaponId] = currentLevel + 1;
    UI.showNotification('⚒️ تم تطوير ' + WEAPONS[weaponId].name + ' إلى Lv.' + (currentLevel + 1));
    UI.updateHUD(this);
    return true;
  },

  gameOver() {
    this.gameRunning = false;
    document.getElementById('finalCoins').textContent = this.coins;
    document.getElementById('finalPoints').textContent = this.points;
    document.getElementById('finalLevel').textContent = this.level;
    document.getElementById('gameOver').style.display = 'flex';
  },

  start() {
    this.reset();
    this.gameRunning = true;
    document.getElementById('startScreen').style.display = 'none';
    document.getElementById('gameOver').style.display = 'none';
    UI.updateHUD(this);
    console.log('▶️ اللعبة بدأت. player:', this.player.x, this.player.y, 'camera:', this.camera.x, this.camera.y, 'W×H:', this.W, '×', this.H);
  }

});
