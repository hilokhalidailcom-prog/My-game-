// ===== نقطة البداية =====
window.addEventListener('DOMContentLoaded', () => {
  UI.init();
  window.game = new Game();
  window.player = window.game.player;

  // ===== إعداد joystick =====
  const joystickZone = document.getElementById('joystickZone');
  const joystickKnob = document.getElementById('joystickKnob');
  const joystick = { active: false, id: null, baseX: 0, baseY: 0, maxDist: 50 };

  function getTouchPos(e, id) {
    const touches = e.changedTouches || e.touches;
    for (let i = 0; i < touches.length; i++) {
      if (touches[i].identifier === id) return { x: touches[i].clientX, y: touches[i].clientY };
    }
    return null;
  }

  function updateJoystick(px, py) {
    let dx = px - joystick.baseX;
    let dy = py - joystick.baseY;
    const d = Math.hypot(dx, dy);
    if (d > joystick.maxDist) {
      dx = dx / d * joystick.maxDist;
      dy = dy / d * joystick.maxDist;
    }
    window.game.joystick.dx = dx / joystick.maxDist;
    window.game.joystick.dy = dy / joystick.maxDist;
    joystickKnob.style.transform = `translate(${dx}px, ${dy}px)`;
  }

  joystickZone.addEventListener('touchstart', (e) => {
    e.preventDefault();
    const t = e.changedTouches[0];
    const rect = joystickZone.getBoundingClientRect();
    joystick.active = true;
    joystick.id = t.identifier;
    joystick.baseX = rect.left + rect.width / 2;
    joystick.baseY = rect.top + rect.height / 2;
    updateJoystick(t.clientX, t.clientY);
  }, { passive: false });

  joystickZone.addEventListener('touchmove', (e) => {
    e.preventDefault();
    const t = getTouchPos(e, joystick.id);
    if (t) updateJoystick(t.x, t.y);
  }, { passive: false });

  function endJoystick(e) {
    const t = getTouchPos(e, joystick.id);
    if (t || e.type === 'touchend') {
      joystick.active = false;
      joystick.id = null;
      window.game.joystick.dx = 0;
      window.game.joystick.dy = 0;
      joystickKnob.style.transform = 'translate(0,0)';
    }
  }
  joystickZone.addEventListener('touchend', endJoystick);
  joystickZone.addEventListener('touchcancel', endJoystick);

  joystickZone.addEventListener('mousedown', (e) => {
    e.preventDefault();
    const rect = joystickZone.getBoundingClientRect();
    joystick.active = true;
    joystick.id = 'mouse';
    joystick.baseX = rect.left + rect.width / 2;
    joystick.baseY = rect.top + rect.height / 2;
    updateJoystick(e.clientX, e.clientY);
  });
  window.addEventListener('mousemove', (e) => {
    if (joystick.active && joystick.id === 'mouse') updateJoystick(e.clientX, e.clientY);
  });
  window.addEventListener('mouseup', () => {
    if (joystick.id === 'mouse') {
      joystick.active = false;
      joystick.id = null;
      window.game.joystick.dx = 0;
      window.game.joystick.dy = 0;
      joystickKnob.style.transform = 'translate(0,0)';
    }
  });

  // ===== زر الإطلاق =====
  const shootBtn = document.getElementById('shootBtn');
  shootBtn.addEventListener('touchstart', (e) => { e.preventDefault(); window.game.firing = true; shootBtn.classList.add('pressed'); }, { passive: false });
  shootBtn.addEventListener('touchend', (e) => { e.preventDefault(); window.game.firing = false; shootBtn.classList.remove('pressed'); });
  shootBtn.addEventListener('touchcancel', () => { window.game.firing = false; shootBtn.classList.remove('pressed'); });
  shootBtn.addEventListener('mousedown', (e) => { e.preventDefault(); window.game.firing = true; shootBtn.classList.add('pressed'); });
  window.addEventListener('mouseup', () => { window.game.firing = false; shootBtn.classList.remove('pressed'); });

  // ===== زر تغيير السلاح =====
  const switchBtn = document.getElementById('switchBtn');
  function switchWeapon() {
    if (window.game.unlockedWeapons.length <= 1) return;
    const idx = window.game.unlockedWeapons.indexOf(window.game.currentWeapon);
    window.game.currentWeapon = window.game.unlockedWeapons[(idx + 1) % window.game.unlockedWeapons.length];
    UI.updateHUD(window.game);
  }
  switchBtn.addEventListener('touchstart', (e) => { e.preventDefault(); switchBtn.classList.add('pressed'); switchWeapon(); }, { passive: false });
  switchBtn.addEventListener('touchend', () => switchBtn.classList.remove('pressed'));
  switchBtn.addEventListener('click', (e) => { e.preventDefault(); switchWeapon(); });

  // ===== الأزرار الجانبية =====
  document.getElementById('shopBtn').addEventListener('click', () => openShop());
  document.getElementById('inventoryBtn').addEventListener('click', () => openInventory());
  document.getElementById('upgradeBtn').addEventListener('click', () => openUpgrade());

  document.querySelectorAll('.close-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const modalId = btn.dataset.close;
      document.getElementById(modalId).classList.remove('open');
    });
  });

  document.querySelectorAll('.modal-tabs').forEach(tabs => {
    tabs.querySelectorAll('.tab').forEach(tab => {
      tab.addEventListener('click', () => {
        tabs.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        const modal = tabs.closest('.modal');
        if (modal.id === 'shopModal') renderShopBody(tab.dataset.tab);
        else if (modal.id === 'inventoryModal') renderInventoryBody(tab.dataset.tab);
      });
    });
  });

  document.getElementById('startBtn').addEventListener('click', () => {
    SFX.unlock();
    window.game.start();
    console.log('✅ اللعبة بدأت - W:', window.game.W, 'H:', window.game.H);
  });
  document.getElementById('retryBtn').addEventListener('click', () => {
    SFX.unlock();
    window.game.start();
  });

  // ===== المتجر =====
  function openShop() {
    if (!window.game.gameRunning) return;
    document.getElementById('shopModal').classList.add('open');
    const activeTab = document.querySelector('#shopModal .tab.active');
    renderShopBody(activeTab ? activeTab.dataset.tab : 'followers');
  }

  function renderShopBody(tab) {
    const body = document.getElementById('shopBody');
    body.innerHTML = '';

    if (tab === 'followers') {
      for (const f of SHOP_ITEMS.followers) {
        const type = FOLLOWER_TYPES[f.typeId];
        const canAfford = window.game.coins >= f.price;
        const div = document.createElement('div');
        div.className = 'shop-item';
        div.innerHTML = `
          <div class="icon" style="background:${type.color}">${f.icon}</div>
          <div class="info">
            <b>${f.name}</b>
            <div class="desc">${f.desc}<br>❤️ ${type.hp} | ⚔️ ${type.damage} | 📏 ${type.range}</div>
          </div>
          <div class="price">
            💰 ${f.price}
            <button ${canAfford ? '' : 'disabled'} data-action="buy-follower" data-type="${f.typeId}" data-price="${f.price}">شراء</button>
          </div>
        `;
        body.appendChild(div);
      }
    } else if (tab === 'items') {
      for (const item of SHOP_ITEMS.items) {
        const it = ITEM_TYPES[item.id];
        const canAfford = window.game.coins >= item.price;
        const owned = window.game.inventory[item.id] || 0;
        const div = document.createElement('div');
        div.className = 'shop-item';
        div.innerHTML = `
          <div class="icon" style="background:${it.color}">${it.icon}</div>
          <div class="info">
            <b>${it.name} ${owned > 0 ? '(تملك ' + owned + ')' : ''}</b>
            <div class="desc">${it.desc}</div>
          </div>
          <div class="price">
            💰 ${item.price}
            <button ${canAfford ? '' : 'disabled'} data-action="buy-item" data-id="${item.id}" data-price="${item.price}">شراء</button>
          </div>
        `;
        body.appendChild(div);
      }
    } else if (tab === 'weapons') {
      const div = document.createElement('div');
      div.className = 'empty-msg';
      div.innerHTML = '🔫 الأسلحة تُفتح تلقائياً بترقية المستوى<br>طوّرها من زر ⚒️';
      body.appendChild(div);
    }

    body.querySelectorAll('button[data-action]').forEach(btn => {
      btn.addEventListener('click', () => {
        if (btn.dataset.action === 'buy-follower') {
          if (window.game.buyFollower(btn.dataset.type, parseInt(btn.dataset.price))) {
            renderShopBody(tab);
          }
        } else if (btn.dataset.action === 'buy-item') {
          if (window.game.buyItem(btn.dataset.id, parseInt(btn.dataset.price))) {
            renderShopBody(tab);
          }
        }
      });
    });
  }

  // ===== الحقيبة =====
  function openInventory() {
    if (!window.game.gameRunning) return;
    document.getElementById('inventoryModal').classList.add('open');
    const activeTab = document.querySelector('#inventoryModal .tab.active');
    renderInventoryBody(activeTab ? activeTab.dataset.tab : 'items');
  }

  function renderInventoryBody(tab) {
    const body = document.getElementById('inventoryBody');
    body.innerHTML = '';

    if (tab === 'items') {
      const itemIds = Object.keys(window.game.inventory).filter(id => window.game.inventory[id] > 0);
      if (itemIds.length === 0) {
        body.innerHTML = '<div class="empty-msg">🎒 لا توجد أدوات<br>اشترِ من المتجر 🏪</div>';
        return;
      }
      for (const id of itemIds) {
        const it = ITEM_TYPES[id];
        const count = window.game.inventory[id];
        const div = document.createElement('div');
        div.className = 'inv-item';
        div.innerHTML = `
          <div class="icon" style="background:${it.color}">${it.icon}</div>
          <div class="info">
            <b>${it.name} ×${count}</b>
            <div class="desc">${it.desc}</div>
          </div>
          <button data-action="use-item" data-id="${id}">استخدام</button>
        `;
        body.appendChild(div);
      }
      body.querySelectorAll('button[data-action="use-item"]').forEach(btn => {
        btn.addEventListener('click', () => {
          window.game.useItem(btn.dataset.id);
          renderInventoryBody('items');
        });
      });
    } else if (tab === 'weapons') {
      for (const wid of window.game.unlockedWeapons) {
        const w = WEAPONS[wid];
        const lvl = window.game.weaponLevels[wid] || 1;
        const stats = getWeaponStats(wid, lvl);
        const isCurrent = wid === window.game.currentWeapon;
        const div = document.createElement('div');
        div.className = 'inv-item';
        div.innerHTML = `
          <div class="icon" style="background:${w.color}">🔫</div>
          <div class="info">
            <b>${w.name} Lv.${lvl} ${isCurrent ? '✓' : ''}</b>
            <div class="desc">⚔️ ${stats.damage} | ⏱️ ${stats.cooldown}ms</div>
          </div>
          ${!isCurrent ? '<button data-action="equip" data-id="' + wid + '">تجهيز</button>' : ''}
        `;
        body.appendChild(div);
      }
      body.querySelectorAll('button[data-action="equip"]').forEach(btn => {
        btn.addEventListener('click', () => {
          window.game.currentWeapon = btn.dataset.id;
          UI.updateHUD(window.game);
          renderInventoryBody('weapons');
        });
      });
    } else if (tab === 'followers') {
      if (window.game.followers.length === 0) {
        body.innerHTML = '<div class="empty-msg">👥 لا يوجد أتباع<br>اشترِ من المتجر 🏪</div>';
        return;
      }
      for (const f of window.game.followers) {
        const isMax = f.level >= MAX_FOLLOWER_LEVEL;
        const cost = getFollowerUpgradeCost(f.level);
        const canAfford = window.game.coins >= cost.coins && window.game.points >= cost.points;
        const div = document.createElement('div');
        div.className = 'shop-item';
        div.innerHTML = `
          <div class="icon" style="background:${f.type.color}">${f.type.icon}</div>
          <div class="info">
            <b>${f.type.name} — Lv.${f.level}${isMax ? ' (أقصى)' : ''}</b>
            <div class="desc">❤️ ${Math.ceil(f.hp)}/${f.maxHp} | ⚔️ ${f.damage}</div>
          </div>
          ${!isMax ? `
            <div class="price">
              💰 ${cost.coins}<br>⭐ ${cost.points}
              <button ${canAfford ? '' : 'disabled'} data-action="upgrade-follower" data-id="${f.id}">تطوير</button>
            </div>
          ` : '<div class="price">✅</div>'}
        `;
        body.appendChild(div);
      }
      body.querySelectorAll('button[data-action="upgrade-follower"]').forEach(btn => {
        btn.addEventListener('click', () => {
          if (window.game.upgradeFollower(btn.dataset.id)) {
            renderInventoryBody('followers');
          }
        });
      });
    }
  }

  // ===== التطوير =====
  function openUpgrade() {
    if (!window.game.gameRunning) return;
    document.getElementById('upgradeModal').classList.add('open');
    renderUpgradeBody();
  }

  function renderUpgradeBody() {
    const body = document.getElementById('upgradeBody');
    body.innerHTML = '';

    for (const wid of window.game.unlockedWeapons) {
      const w = WEAPONS[wid];
      const lvl = window.game.weaponLevels[wid] || 1;
      const isMax = lvl >= MAX_WEAPON_LEVEL;
      const cost = getUpgradeCost(wid, lvl);
      const canAfford = window.game.coins >= cost.coins && window.game.points >= cost.points;
      const stats = getWeaponStats(wid, lvl);
      const nextStats = !isMax ? getWeaponStats(wid, lvl + 1) : null;

      const div = document.createElement('div');
      div.className = 'shop-item';
      div.innerHTML = `
        <div class="icon" style="background:${w.color}">🔫</div>
        <div class="info">
          <b>${w.name} — Lv.${lvl}${isMax ? ' (أقصى)' : ''}</b>
          <div class="desc">
            ⚔️ ضرر: ${stats.damage}${nextStats ? ' → ' + nextStats.damage : ''}<br>
            ⏱️ سرعة: ${stats.cooldown}ms${nextStats ? ' → ' + nextStats.cooldown + 'ms' : ''}
          </div>
        </div>
        ${!isMax ? `
          <div class="price">
            💰 ${cost.coins}<br>⭐ ${cost.points}
            <button ${canAfford ? '' : 'disabled'} data-action="upgrade" data-id="${wid}">تطوير</button>
          </div>
        ` : '<div class="price">✅</div>'}
      `;
      body.appendChild(div);
    }

    body.querySelectorAll('button[data-action="upgrade"]').forEach(btn => {
      btn.addEventListener('click', () => {
        if (window.game.upgradeWeapon(btn.dataset.id)) {
          renderUpgradeBody();
        }
      });
    });
  }

  // ===== حلقة اللعبة =====
  function loop() {
    try {
      window.game.update();
      window.game.draw();
    } catch (err) {
      console.error('❌ خطأ في حلقة اللعبة:', err);
    }
    requestAnimationFrame(loop);
  }
  loop();

  console.log('✅ تم تحميل اللعبة. جاهز للبدء.');
});